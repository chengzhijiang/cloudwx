//app.js
App({
  onLaunch: function () {
   wx.cloud.init({
     env:'',
     traceUser:true
   })
   wx.getSystemInfo({
    success: e => {
      this.globalData.StatusBar = e.statusBarHeight;
      let custom = wx.getMenuButtonBoundingClientRect();
      this.globalData.Custom = custom;
      this.globalData.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
    }
  })
   // 获取顶部栏信息
   wx.getSystemInfo({
    success: res => {
      //导航高度
      this.globalData.navHeight = res.statusBarHeight;
    }, fail(err) {
      console.log(err);
    }
  })
},
globalData: {
     swiperList: [{
          id: 0,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (1).jpg'
        }, {
          id: 1,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (2).jpg',
        }, {
          id: 2,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (3).jpg'
        }, {
          id: 3,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (4).jpg'
        }, {
          id: 4,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (5).jpg'
        }, {
          id: 5,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (6).jpg'
        }, {
          id: 6,
          type: 'image',
          url: 'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/touxiang/touxiang (7).jpg'
        }],
    navHeight: 0,
  },

})