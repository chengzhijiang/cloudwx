const cloud = require('wx-server-sdk')

cloud.init()
//初始化云函数
const db = cloud.database()
// 云函数入口函数
// 获取加入数据库商品的信息
exports.main = async (event, context) => {
//collection里面时要增加数据的表的名称
try {
   //这里的update依据是event.user_id
   return await db.collection("users").doc(event.user_id).update({
    data: {
      approve:event.approve,
      al_approve:event.approve,
      Community_manager:event.Community_manager,
      offcialCommunity:event.offcialCommunity,
      Merchants:event.Merchants,
      Canteen_type:event.Canteen_type
    }, success: res => {
      //wx.showToast({
       // title: '订单发起成功',
      //})
    }, fail: err => {
      //wx.showToast({
        //icon: 'none',
        //title: '订单发起失败',
      //})
    }
  })
}catch (e) {
  console.log(e)
}
}
