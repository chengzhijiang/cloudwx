// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
let Community_id = event.Community_id
  try{
  return await db.collection('users').doc(event.user_id).update({
    data: {
      Community: _.pull({
        Community_id
      })
    }
  });
  }catch (e) {
    console.log(e)
  }
}

