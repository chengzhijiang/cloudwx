// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
    try{
      const result = await cloud.openapi.wxacode.get({
        path:'event.path',
        width: 430
      })
      console.log(result)
      const upload = await cloud.uploadFile({
       cloudPath:'twoCode/'+Date.now()+'-'+Math.random()+'.png',//存放的名字和路径
       fileContent:result.buffer
      })
  return upload
    }catch(err){
    console.log(err)
    return err
  }
  
  }
  