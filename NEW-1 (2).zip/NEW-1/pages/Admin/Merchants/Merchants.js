var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
          //闲置分类导航栏
          categories: ["商户", "每日推荐", "水果配送"],
          //当前下标
          currentData:0,
          // 数据
          constants:[],
          //所要读取的数据库
          database:'constants',
          //数据库数量
          count: "",
          //下拉更新数据库数据个数
          nextPage: 0,
          //我的页面
          myPage: true,
  },
  onLoad:function(){
    this.userLoad()
  },
    // 调用util.js中读取数据库函数
    userLoad: function () {
      var that = this;
        console.log('ask:', that.data.database);
        util.serachshouye(that);  
    },
  
  upMenu:function(){
    wx.navigateTo({
      url: '../../Post/upMenu/upMenu',
    })
  },
   //滑动更新主导航栏下标
    categoriesTab: function (e) {
      this.setData({
       // currentIndex: e.currentTarget.dataset.index
       currentData: e.currentTarget.dataset.index
      })
      console.log(this.data.currentData)
      if(this.data.currentData == 0){
        this.setData({
        eatmode:true
        })
      }else if(this.data.currentData == 1){
        this.setData({
        eatmode:false
        })
      }
    },
            //更新副导航栏下标
            categoriesChange: function (e) {
              let current = e.detail.current;
              let source = e.detail.source
              //console.log(source);
              // 这里的source是判断是否是手指触摸 触发的事件
              if (source === 'touch') {
                this.setData({
                  currentData: current
                })
                console.log(this.data.currentData)
              }
            },
              //删除商品
              deleteGood: function(e) {
    var that=this
    var id = e.currentTarget.id
    //获得帖子id
    var Menu_id = this.data.constants[id].category.category_id
    var Menu_name = this.data.constants[id].category.name
    wx.showModal({
      title: '删除物品',
      content: Menu_name,
      success(res) {
        // 删除云上的帖子的图片
        // that.removeImage(that.data.constants[id].iamges)
        //用户点击删除就删除帖子
        if (res.confirm) {
          const db = wx.cloud.database()
          const _ = db.command;
          db.collection('constants')
          .where({Menu_id})
          .update({
            data:{
              category: _.pull({                           //看下面的解释
                category_id: _.eq(experience.awards),
                category_name: _.eq(Menu_name),
                image: _.eq(experience.labor),
                category_price: _.eq(experience.labor),
              })
            },
            //删除成功显示提示
            success: function (res) {
              console.log("删除成功")
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 1000
              })
              that.setData({
                feed: [],
                nextPage: 0,
              })
              that.userLoad();
            }
          })
        }
      }
    })
  },

  // 删除云上的图片
  removeImage: function (iamges) {
    console.log(iamges)
    // 不删除默认图片
    if(iamges[0]!="cloud://yf-ab2989.7966-yf-ab2989-1258230310/没有实物图.png"){
      wx.cloud.deleteFile({
        fileList: iamges
      }).then(res => {
        console.log(res.fileList)
      }).catch(error => {
      })
      console.log("成功删除图片")
    }

  },

})