var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //获取的二手物品数据
    feed: [],
    //下拉继续读取数据
    nextPage: 0,
    //用户id openid
    openid: "",
    //获取到的社长信息
    Clubmember_data:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      //获取社团信息
      this.getUserData()
  },



  // 拖到最下面更新数据
  lower: function (e) {
    wx.showNavigationBarLoading();
    var that = this;
    // setTimeout(function(){wx.hideNavigationBarLoading();that.allLoad();}, 1000);
    that.allLoad();
    console.log("lower")
  },
//查询自己管理的社团
  // 获取帖子主人的信息
  getUserData:function(){
    var that = this
    const db = wx.cloud.database()
    // 查询当前帖子的主人信息
    db.collection('Community').where({
      "_openid":app.globalData.userCloudData._openid,
    }).get({
      success: res => {
        this.setData({
          Clubmember_data:res.data[0]
        })
        console.log('[数据库] [查询记录] 成功: ', this.data.Clubmember_data)
        console.log(this.data.Clubmember_data._id)
            //调用获取用户信息数据
            this.allLoad();
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    });
  },
  // 在云数据库上查找数据(查找10条)
  allLoad: function () {
    var that = this;
    var offcialCommunity = this.data.Clubmember_data._id
    console.log(offcialCommunity)
    // util.allLoad('users', that, '.');
    //查询所有用户
    const db = wx.cloud.database()
    db.collection('users')
    .where({
        "offcialCommunity": offcialCommunity
      })
      .orderBy('date', 'desc')
      .skip(that.data.nextPage)
      .limit(10) // 限制返回数量为 10 条
      .get({
        //成功读取写入数据
        success: res => {
          that.setData({
            feed: this.data.feed.concat(res.data),
            nextPage: this.data.nextPage + 10
          })
          console.log('[数据库] [查询记录] 成功: ', that.data.feed)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      });
    console.log(this.data.feed)
  },

  // 发送模板消息
  sendTemplate: function (approve, user_openid) {
    console.log(user_openid)
    wx.cloud.init()
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendRegisteredMessage',
        approve: approve,
        user_openid: user_openid
      },
      success: res => {
        console.warn('[云函数] [openapi] templateMessage.send 调用成功：', res)
        wx.showModal({
          title: '发送成功',
          content: '成功发送信息',
          showCancel: false,
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '调用失败',
        })
        console.error('[云函数] [openapi] templateMessage.send 调用失败：', err)
      }
    })
  },

  //不通过用户验证
  removeUser: function (e) {
    const idx = e.target.dataset.idx
    //获得帖子id
    var that = this
    var user_id = this.data.feed[idx]._id
    var users_Name = this.data.feed[idx].nick_name
    var user_openid  =  this.data.feed[idx]._openid
    wx.showModal({
      title: '移除社员',
      content: users_Name,
      success(res) {
        if (res.confirm) {
          // 通过用户验证
          const db = wx.cloud.database()
          wx.cloud.callFunction({
            name: 'approvePass',
            data: {
              user_id: user_id,
              offcialCommunity:123456
            }, success: function (res) {
              console.log("修改成功" + res)
            }, fail: function (res) {
              console.log(res)
            }
          })
          // 调用模板消息发送消息
          that.sendTemplate("认证不成功", user_openid)
        }
      }

    })



  },

  //用户点击放大图片
  handleImagePreview:function(e) {
    var index = e.target.dataset.index
    console.log(e)
    var images = this.data.feed[index].approve_img
    wx.previewImage({
      current: images[index],  //当前预览的图片
      urls: images,  //所有要预览的图片
    })
  },

  //刷新注册用户
  refresh:function() {
    this.setData({
      //获取的二手物品数据
      feed: [],
      //下拉继续读取数据
      nextPage: 0,
    })
    this.allLoad();
  }


})