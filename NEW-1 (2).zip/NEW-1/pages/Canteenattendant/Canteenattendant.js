var util = require('../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
                // 数据
                feed:[],
                //所要读取的数据库
                database:'constants',
                //数据库数量
                count: "",
                //下拉更新数据库数据个数
                nextPage: 0,
                //我的页面
                myPage: true,
                Menuimages:[],
                Menu_name:"",
                Menu_price:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
       this.setData({
        userData: app.globalData.userCloudData,
        user_Canteen_type:app.globalData.userCloudData.Canteen_type,
       })
       console.log(this.data.user_Canteen_type)
       this.userLoad()
  },
    // 调用util.js中读取数据库函数
    userLoad: function (e) {
      var that = this;
        console.log('ask:', that.data.database);
        util.searchmyMerchants(that);
    },

     //删除商品
     deleteDishes: function(e) {
    var that=this
    var id = e.currentTarget.dataset.idx
    //获得帖子id
    var Dishes = this.data.feed[0].category[id]
    var Dishes_name = this.data.feed[0].category[id].category_name
    wx.showModal({
      title: '删除帖子',
      content: Dishes_name,
      success(res) {
        // 删除云上的帖子的图片
        that.removeImage(that.data.feed[id].iamges)
        //用户点击删除就删除帖子
        if (res.confirm) {
          const db = wx.cloud.database()
          db.collection('luntan').doc(luntan_id).remove({
            //删除成功显示提示
            success: function (res) {
              console.log("删除成功")
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 1000
              })
              that.setData({
                feed: [],
                nextPage: 0,
              })
              that.userLoad();
            }
          })
        }
      }
    })
  },
  // 删除云上的图片
  removeImage: function (iamges) {
    console.log(iamges)
    // 不删除默认图片
    if(iamges[0]!="cloud://yf-ab2989.7966-yf-ab2989-1258230310/没有实物图.png"){
      wx.cloud.deleteFile({
        fileList: iamges
      }).then(res => {
        console.log(res.fileList)
      }).catch(error => {
      })
      console.log("成功删除图片")
    }

  },
  // 上传菜品
  upMenudetail:function(e){
    console.log(e)
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
    //隐藏模态窗口
modalChange1(e) {
  this.setData({
    modalName1: null
  })
},
  //隐藏拟态窗口
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  uploadMenu(e){
    this.setData({
      Menu_name:e.detail.value.Menu_name,
      Menu_price:e.detail.value.Menu_price
    })
    console.log('321',this.data.constants)
    console.log('213',this.data.Canteentype)
    //检查是否有空值
    this.checkMenuInfo()
    if(this.data.infoMode){
      this.uploadMenuImages();
    }
  },
     //检查准备上传的菜品是否有空值
     checkMenuInfo:function() {
if (this.data.Menu_name == "") {
        this.setData({
          warning: "请填写菜品名称"
        })
      }else if (this.data.Menu_price == "") {
        this.setData({
          warning: "请填写菜品价格"
        })
      }else if (this.data.Menuimages.length == 0) {
        this.setData({
          warning: "请上传菜品图片"
        })
      }else {
        this.setData({
          warning: "发布成功",
          display:false,
          infoMode: true,
        })
      }
      // 有错误即弹框提示
      if(!this.data.infoMode){
        this.setData({
          modalName: "Modal",
        })
      }
    },
    //上传菜品图片
   uploadMenuImages:function(){
    var Menuimages=this.data.Menuimages
    //先添加到这一变量,在最后一个再改变this.data.中的Community_Merchantsimages
    var Menu_images=[]
    Menuimages.forEach(item => {
      console.log(item)
      wx.cloud.uploadFile({
        cloudPath: "Merchants_Menu_images/"+item.substring(item.length-20), // 上传至云端的路径
        filePath: item, // 小程序临时文件路径
        success: res => {
          // 返回文件 ID
          console.log(res.fileID)
          Menu_images.push(res.fileID)
          console.log('这是路径',Menu_images)
          //获取所有图片在云端的位置后上传到数据库
          if(Menu_images.length===Menuimages.length){
            //将局部变量赋给this.data
            this.setData({
              Menu_images:Menu_images
            })
            console.log('这是第二路径',this.data.Menu_images)
            
            //隐藏上传提示
            wx.hideLoading()
            this.uploadMenuData()
          }
        },
        fail: console.error
      })
    });
  },
    //将更换完的背景图上传到数据库
    uploadMenuData:function() {
      console.log("上传数据")
      const db = wx.cloud.database()
      const _ = db.command
      db.collection("constants")
      .where({
        name:this.data.user_Canteen_type
      })
      .update({
        data: {
          "category":_.push({
            category_name:this.data.Menu_name,
            image:this.data.Menu_images,
            category_price:this.data.Menu_price,
            Soldout:false}),
        },
        success: function (res) {
          //成功上传后提示信息
          console.log("上传成功")
          wx.showLoading({
            title: '上传菜品成功',
            icon: 'success',
            duration: 1000,
          })
          wx.redirectTo({
            url: "../Canteenattendant/Canteenattendant?tab_id=" + 0
          })
        }
      })
    },
      //选择图片
 chooseMenuImage: function(e) {
  var that = this;
  if (that.data.Menuimages.length < 1) {
    wx.chooseImage({
      count: 1, //最多可以选择的图片张数
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        this.setData({
          Menuimages:this.data.Menuimages.concat(res.tempFilePaths)
        })
        console.log(this.data.Menuimages)
      }
    });
  } else {
    wx.showToast({
      title: "图片限传一张！",
      icon: 'none',
      duration: 2000,
      mask: true,
    });
  }
},
//售完显示
Soldout:function(e){
  console.log(e)
  var id = e.currentTarget.dataset.idx
  //获得帖子id
  var Dishes_id = this.data.feed[0].category[id]
  console.log(Dishes_id)
},
Soldout:function(e){
  var that = this
  var id = e.currentTarget.dataset.idx
  var order_id = this.data.feed[0]._id
  console.log(order_id)
  wx.showModal({
    title:'确认售完',
    content: "确认该菜品已售完？"+this.data.feed[0].category[id].category_name,
    success (res) {
      if (res.confirm) {
        console.log("上传数据")
        const db = wx.cloud.database()
        const _ = db.command
        db.collection("constants").doc(order_id).update({
          data: {
            ['category'+[id]]:Soldout
          },
          success: function (res) {
            that.uploadorder()
            //成功上传后提示信息
            wx.showLoading({
              title: '设置成功',
              icon: 'success',
              duration: 1000,
            })
          }
        })
      } else if (res.cancel) {
        console.log('用户点击取消')
      }
    }
})
},
})