
var util = require('../../utils/util.js')
Page({
 properties: {},
  // 数据绑定
  data: {
    navH: 0,
    rotationList:[
      'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/swiper/shetuan1.jpg',
      'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/swiper/shetuan2.jpg',
      'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/swiper/shetuan3.jpg',
      'cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/swiper/shetuan4.jpg'
    ],
    swiperCurrent: 0,
    //主导航栏
    navbar:[
      {
        icon: "../../images/zixun/huodong.png",
        text:"最新活动"
      },{
        icon: "../../images/zixun/shetuan1.png",
        text:"社团介绍"
      },{
        icon: "../../images/zixun/shiyan.png",
        text:"实验预约"
      },
      {
        icon: "../../images/zixun/Recruitment.png",
        text:"校园工作"
      }
    ],
    // 主导航栏下标
    currentIndex:0,
     //分类导航栏下标
       currentData: 0,
        //所要读取的数据库
        database:'Community',
        //数据库数量
        count: "",
        //数据库数据
        feed: [],
        //下拉更新数据库数据个数
        nextPage: 0,
        //旋转动画
        animationList: [], //这是数组 存放动画
        //头像列表
        swiperList:[],
        //用户信息
        user_id: "",
        user_data: {},
        community_data:[],
        // 显示时间样式
        calendar:[],
  width:0,
  currentIndex:0,
  currentTime: 0,
  timeArr: [
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" },
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-10:00", "status": "约满" }, 
      { "time": "8:00-22:00", "status": "约满" }
      ]  
  },
  onLoad:function(){
        // 根据点击查找数据库
        this.navbarTab();
        this.setData({
          user_id:this.data.feed._openid,
        })

  },


      //滑动更新主导航栏下标
  navbarTab: function (e) {
    var index = e.currentTarget.dataset.index;
    var item = this.data.navbar[index].animation; //获取每一个的动画

    if (e) {
      this.setData({
        currentIndex: e.currentTarget.dataset.index,
        currentData: 0,
        float_show: false,
      });
    }
    // console.log(this.data.currentIndex)
    var that = this;
    if (that.data.currentIndex == 0) {
      that.setData({
        feed: [],
        nextPage: 0,
        categories1: ["全部","教育","科技","公益","组织","文娱","体育","比赛"],
        database: 'CommunityActivity',
        currentData: this.data.currentData,
      })
      that.getUserData()
    } else if (that.data.currentIndex == 1) {
      that.setData({
        feed: [],
        count: 0,
        nextPage: 0,
        categories1: ["全部","学术科技", "体育竞技", "文化艺术", "公益实践","创新创业"],
        database: 'Community',
        currentData:this.data.currentData,
      })
    }
    this.databaseLoad();
    let animation = wx.createAnimation({ //实例化一个动画
      // 动画持续时间，单位ms，默认值 400
      duration: 200,
      timingFunction: 'linear',
    })
    this.data.navbar.forEach((item, index) => { //每次点击清除之前的所有动画效果
      if (item.animation) { //如果有动画就把动画执行回去，这里考虑过直接清除对象内容，item.animation = {},内容是清楚了，但是界面的效果是保留了之前的操作的。
        animation.scale(1).step(); //变回原形
        animation.rotate(0).step() //执行旋转180度的效果
        this.data.navbar[index].animation = animation.export() //把动画渲染出去
      }
      this.setData({     //保存动画内容并渲染到页面
        navbar: this.data.navbar
      })
    });
    animation.scale(1.1).step(); //执行点击放大的效果
    animation.rotate(180).step() //执行旋转180度的效果
    this.data.navbar[index].animation = animation.export() //渲染动画

    this.setData({  //保存动画内容并渲染到页面
      navbar: this.data.navbar
    })
  },
    //滑动更新主导航栏下标
    categoriesTab: function (e) {
      this.setData({
        // currentIndex: e.currentTarget.dataset.index
        currentData: e.currentTarget.dataset.index,
        float_show: false,
      })
      console.log(this.data.currentData)
  
      // 判断如果为寻物和找队友则更改搜索的数据库
      if (this.data.currentIndex == "2") {
        // 根据所选tab更改查找的数据库
        this.discoverType();
      }
    },

   // 调用util.js中读取数据库函数
   databaseLoad: function () {
    var that = this;
    if (that.data.currentIndex == 1 || (that.data.currentIndex == 2 && that.data.currentData == 0)){
      util.onlyLoad(that);
    } else if (that.data.currentIndex == 0){
      util.onlyLoad(that);
    }
  },
  lower: function (e) {
    wx.showNavigationBarLoading();
    var that = this;
    // setTimeout(function(){wx.hideNavigationBarLoading();that.databaseLoad();}, 1000);
    that.databaseLoad();
    console.log("lower")
  },

  onLoad: function(options) {
    currentIndex: options.tab_id
    if (options.category_id != "") {
      this.setData({
        currentIndex: options.tab_id,
        currentData: options.category_id
      })
    }
    this.navbarTab();
  },
 //  打开新闻详情页事件
 onPostTap:function(e){
   console.log(e)
  // 获取新闻的postId
  var postId = e.currentTarget.id;
  console.log(e.currentTarget.id)
  console.log(this.data.feed[postId])
  var post_data = JSON.stringify(this.data.feed[postId])

  if(this.data.feed[postId].Community_type=="活动"){
    wx.navigateTo({
      // url: '../posttest/posttest?post_data=' + post_data
   
      url: '../Index/contact_Activity_Community/contact_Activity_Community?post_data=' + post_data
    })
  }else{
    wx.navigateTo({
      // url: '../posttest/posttest?post_data=' + post_data
      url: '../Index/contact_Community/contact_Community?post_data='+post_data,
    })
  }
  wx.navigateTo({

  })
},
  //更新副导航栏下标
  categoriesChange: function (e) {
    let current = e.detail.current;
    let source = e.detail.source
    //console.log(source);
    // 这里的source是判断是否是手指触摸 触发的事件
    if (source === 'touch') {
      this.setData({
        currentData: current,
        float_show: false,
      })
      console.log(this.data.currentData)
      // 判断如果为寻物和找队友则更改搜索的数据库
      if (this.data.currentIndex == "2") {
        // 根据所选tab更改查找的数据库
        this.discoverType()
      }
    }
  },
    // 判断发现 的分类(求助 寻物 找队友)
    discoverType: function () {
      this.setData({
        feed: [],
        nextPage: 0,
      })
      if (this.data.currentData == 0) {
        this.setData({
          count: 0,
          database: "recourse",
        })
        this.databaseLoad();
      } else if (this.data.currentData == 1) {
        util.discoverLoad("寻物", this);
      }
      else {
        util.discoverLoad("找队友", this);
      }
    },

//根据活动查找相应的社团
  // 获取帖子主人的信息
  getUserData:function(){
    const db = wx.cloud.database()
    // 查询当前帖子的主人信息
    db.collection('Community').where({
      _openid:this.data.user_id
    }).get({
      success: res => {
        this.setData({
          community_data:res.data[0]
        })
        console.log('[数据库] [查询记录] 成功: ', this.data.community_data)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    });
  },
  select:function(event){
    //为上半部分的点击事件
    this.setData({
     currentIndex: event.currentTarget.dataset.index
    })
    console.log(event.currentTarget.dataset.date)
   },
   selectTime:function(event){
    //为下半部分的点击事件
    this.setData({
     currentTime: event.currentTarget.dataset.tindex
    })
     console.log(event.currentTarget.dataset.time)
     },
  // 投喂插入数据
  makedate:function(e){
  console.log(e)
  this.setData({
    modalName: e.currentTarget.dataset.target
  })
},
showModal(e) {
  this.setData({
    modalName: e.currentTarget.dataset.target
  })

},
hideModal(e) {
  this.setData({
    modalName: null
  })
},
  //滑动更新主导航栏下标
  categoriesTab: function (e) {
    this.setData({
      // currentIndex: e.currentTarget.dataset.index
      currentData: e.currentTarget.dataset.index
    })
    console.log(this.data.currentData)
  },

  //更新副导航栏下标
  categoriesChange: function (e) {
    let current = e.detail.current;
    let source = e.detail.source
    //console.log(source);
    // 这里的source是判断是否是手指触摸 触发的事件
    if (source === 'touch') {
      this.setData({
        currentData: current
      })
      console.log(this.data.currentData)
    }
  },

})