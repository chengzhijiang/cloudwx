const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
   //送达时间
    express_time: "",
    //详细快递收件地址
    express_destination_detail: "",
    //快递收件地址
    express_destination: "北区生活部 男生宿舍 30号楼",
    express_region: "北区生活部",
    express_destination_1: "男生宿舍",
    express_destination_2: "30号楼",
   //可选快递收件地址
    chooseDestination: [["北区生活部", "南区生活部", "教学楼部"], ["男生宿舍", "女生宿舍"], ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"]],
    //所选快递收件地址下标
    destinationIndex: [0, 0, 0],
    Allprice:'0.00',//价钱
    appointment:{},
    my_appointment:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var post_data=JSON.parse(options.post_data)
    this.setData({
        post_data:post_data,
        express_wechat: app.globalData.userCloudData.wechat_id,
        express_phone: app.globalData.userCloudData.phone,
        Order_name: app.globalData.userCloudData.real_name,
        Order_wechat: app.globalData.userCloudData.wechat_id,
        Order_phone: app.globalData.userCloudData.phone,
    })
    console.log(this.data.post_data)
    var Allprice = 0;
    for (var i = 0; i < post_data.length; i++) {
      var QB = this.data.post_data[i].price;
      var QR = this.data.post_data[i].num;
      Allprice += parseFloat(QB * QR);
    }
    this.setData({
      Allprice:Allprice
    })
    console.log(Allprice)
},
      // 选择快递送达时间
      timeChange(e) {
        this.setData({
          express_time: e.detail.value
        })
      },
            //选择快递收件地址
  destinationChange(e) {
    this.setData({
      destinationIndex: e.detail.value
    })
  },
      //选择快递收件地址
  destinationChange_column(e) {
    let data = {
      chooseDestination: this.data.chooseDestination,
      destinationIndex: this.data.destinationIndex
    };
    data.destinationIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.destinationIndex[0]) {
          case 0:
            data.chooseDestination[1] = ["男生宿舍", "女生宿舍"];
            data.chooseDestination[2] = ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"];
            break;
          case 1:
            data.chooseDestination[1] = ["男生宿舍", "女生宿舍"];
            data.chooseDestination[2] = ["一号宿舍楼","八号宿舍楼","九号宿舍楼","十号宿舍楼","十一号宿舍楼","十二号宿舍楼","十三号宿舍楼","十四号宿舍楼","十五号宿舍楼","十七号宿舍楼"];
            break;
          case 2:
            data.chooseDestination[1] = ["学院教学楼", "公共教学楼"];
            data.chooseDestination[2] = ["计算机与通信工程学院", "理学院", "管理学院", "国际工商学院","聋人工学院","材料学院","自动化学院","艺术学院","工程训练中心","语言文化学院","自动化学院及机械工程学院","化学化工学院","电子信息工程学院","环境科学与安全工程学院"];
            break;
        }
        data.destinationIndex[1] = 0;
        data.destinationIndex[2] = 0;
        break;
      case 1:
        switch (data.destinationIndex[0]) {
          case 0:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"];
                break;
              case 1:
                data.chooseDestination[2] = ["20号宿舍楼", "21号宿舍楼", "22号宿舍楼", "26号宿舍楼", "27号宿舍楼"];
                break;
              // 后面需要补上中区南区等位置
              case 2:case 3:case 4:case 5:
                data.chooseDestination[2]=[]
                break;
            }
            break;
          case 1:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["一号宿舍楼","八号宿舍楼","九号宿舍楼","十号宿舍楼","十一号宿舍楼","十二号宿舍楼","十三号宿舍楼","十四号宿舍楼","十五号宿舍楼","十七号宿舍楼"];
                break;
              case 1:
                data.chooseDestination[2] = ["二号宿舍楼", "三号宿舍楼", "四号宿舍楼", "五号宿舍楼","六号宿舍楼","七号宿舍楼","十六号宿舍楼"];
                break;
            }
            break;
          case 2:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["计算机与通信工程学院", "理学院", "管理学院", "国际工商学院","聋人工学院","材料学院","自动化学院","艺术学院","工程训练中心","语言文化学院","自动化学院及机械工程学院","化学化工学院","电子信息工程学院","环境科学与安全工程学院"];
                break;
              case 1:
                data.chooseDestination[2] = ["一号教学楼", "二号教学楼", "三号教学楼", "四号教学楼","五号教学楼","六号教学楼","二十七号教学楼","28号教学楼"];
                break;
            }
            break;
        }
        data.destinationIndex[2] = 0;
        break;
    }
    this.setData(data);
    this.setData({
      express_destination: this.data.chooseDestination[0][this.data.destinationIndex[0]] + " " + this.data.chooseDestination[1][this.data.destinationIndex[1]] + " " + this.data.chooseDestination[2][this.data.destinationIndex[2]],
      express_region: this.data.chooseDestination[0][this.data.destinationIndex[0]],
      express_destination_1: this.data.chooseDestination[1][this.data.destinationIndex[1]],
      express_destination_2: this.data.chooseDestination[2][this.data.destinationIndex[2]],
    });
  },

  payforit:function(){
    var order_data = {}
    var order_data = { Order:this.data.post_data, Allprice:this.data.Allprice}
    console.log(order_data)
    var post_data = JSON.stringify(order_data)
    wx.redirectTo({
      url: '../../payment_market/payment_market?post_data=' + post_data
    })
  }
})