var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
               //所要读取的数据库
               database: 'order',
               //数据库数量
               count: "",
               //数据库数据
               feed: [],
               //下拉更新数据库数据个数
               nextPage: 0,
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userData: app.globalData.userCloudData,
      user_openid: app.globalData.userCloudData._openid,
    })
    console.log(this.data.userData._openid)
    this.userLoad()
  },
      // 调用util.js中读取数据库函数
      userLoad: function () {
        var that = this;
          console.log('ask:', that.data.database);
          util.searchmyorder(that);
      },
})