var util = require('../../../utils/util.js')
var app = getApp()
Page({
  data:{
        //帖子信息
        post_data:{},
        //头像列表
        swiperList:[],
        // json格式的帖子信息
        ori_post_data: {},
        //用户信息
        user_id: "",
        user_data: {},
        Community_data:{}
  },
  onLoad:function(options){
    var post_data=JSON.parse(options.post_data)
    console.log(post_data)
    this.setData({
      swiperList: app.globalData.swiperList,
        post_data:post_data,
        user_id:post_data._openid,
        ori_post_data: options.post_data,
      });
        // 允许此页面进行转发
    wx.showShareMenu({
      withShareTicket: true
    }); 

    console.log(this.data.post_data)
    console.log(this.data.user_id)

    this.getUserData();
    this.getCommunityData();
  },
  
    // 获取物品主人的信息
    getUserData:function(){
      const db = wx.cloud.database()
      // 查询当前物品的主人信息
      db.collection('users').where({
        _openid:this.data.user_id
      }).get({
        success: res => {
          this.setData({
            user_data:res.data[0]
          })
          console.log('[数据库] [查询记录] 成功: ', this.data.user_data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      });
    },

        // 获取物品主人的信息
        getCommunityData:function(){
          const db = wx.cloud.database()
          // 查询当前物品的主人信息
          db.collection('Community').where({
            _openid:this.data.user_id
          }).get({
            success: res => {
              this.setData({
                Community_data:res.data[0]
              })
              console.log('[数据库] [查询记录] 成功: ', this.data.Community_data)
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '查询记录失败'
              })
              console.error('[数据库] [查询记录] 失败：', err)
            }
          });
        },
      //用户点击放大图片
  handleImagePreview:function(e) {
    var index = e.target.dataset.index
    var images = this.data.post_data.Community_images
    wx.previewImage({
      current: images[index],  //当前预览的图片
      urls: images,  //所有要预览的图片
    })
  },
  
  // 页面分享函数
  onShareAppMessage: function (options) {
    if (options.from === 'button') {
      // 来自页面内转发按钮
      console.log(options.target)
    }
    return {
      //## 此为转发页面所显示的标题
      // title: "快递: "+this.data.express_data.region+" "+this.data.express_data.destination_1+this.data.express_data.destination_2,
      title: "理工校园活动分享",
      path: 'pages/Index/contact_Activity_Community/contact_Activity_Community?post_data=' + this.data.ori_post_data + "&scene=1",
      // imageUrl:this.data.express_data.imgs[0],
      success: function (res) {
        console.log("发送成功")
      },
      fail: function () {
        console.log("发送失败")
      }
    }
  },
})