var util = require('../../../utils/util.js')
var app = getApp()
Page({
  data:{
        //帖子信息
        post_data:{},
        //头像列表
        swiperList:[],
        // json格式的帖子信息
        ori_post_data: {},
        //用户信息
        user_id: "",
        user_data: {},
  },
  onLoad:function(options){
    var post_data=JSON.parse(options.post_data)
    console.log(post_data)
    this.setData({
      swiperList: app.globalData.swiperList,
        post_data:post_data,
        user_id:post_data._openid,
        ori_post_data: options.post_data,
      });
        // 允许此页面进行转发
    wx.showShareMenu({
      withShareTicket: true
    }); 
    this.getUserData()
  },
  
    // 获取物品主人的信息
    getUserData:function(){
      const db = wx.cloud.database()
      // 查询当前物品的主人信息
      db.collection('users').where({
        _openid:this.data.user_id
      }).get({
        success: res => {
          this.setData({
            user_data:res.data[0]
          })
          console.log('[数据库] [查询记录] 成功: ', this.data.user_data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      });
    },

      //用户点击放大图片
  handleImagePreview:function(e) {
    var index = e.target.dataset.index
    var images = this.data.post_data.Community_images
    wx.previewImage({
      current: images[index],  //当前预览的图片
      urls: images,  //所有要预览的图片
    })
  },
  
  async joinclub(){
    var that = this
    if(await this.checkDB(this.data.user_data.Community,this.data.post_data._id)){
      wx.showToast({
        title: '已经申请过该社团了',
        icon:'none',
        duration: 1500
      })
    }else{
      wx.showModal({
        title:'社团加入',
        content: "是否要加入"+this.data.post_data.Community_mainname,
        success (res) {
          if (res.confirm) {
            that.uploadData()
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
// 在用户信息表上加入社团信息
    uploadData:function() {
      console.log("上传数据")
      const db = wx.cloud.database()
      db.collection("users").doc(app.globalData.userCloudData._id).update({
        data: {
          "Community":[this.data.post_data._id],
        },
        success: function (res) {
          //成功上传后提示信息
          console.log("上传成功")
          wx.showLoading({
            title: '成功提交申请',
            icon: 'success',
            duration: 1000,
          })
        }
      })
    },

      //数据库查重
      checkDB(key,value) {
        return new Promise((resolve,reject)=>{
          var Community = [key]
          Community.forEach(item=>{
            console.log(item)
            console.log(value)
            for(let i=0;i<Community.length;i++){
              if(item == value){
                console.log(123)
                resolve(true)
              }else{
                console.log(321)
                resolve(false)
              }
            }

            })
      })
    }
})
