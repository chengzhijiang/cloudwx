var util = require('../../../utils/util.js')
const app = getApp()
// 右侧每一类的 bar 的高度（固定）
const RIGHT_BAR_HEIGHT = 20;
// 右侧每个子类的高度（固定）
const RIGHT_ITEM_HEIGHT = 100;
// 左侧每个类的高度（固定）
const LEFT_ITEM_HEIGHT = 50
Page({
  data: {
    background: ['https://6368-chenzhijiang-4gjcxfns965a56d9-1303874313.tcb.qcloud.la/image1.jpg?sign=44a3fe90bfcd9c048d6b4a7c61732373&t=1611756806',
     'https://6368-chenzhijiang-4gjcxfns965a56d9-1303874313.tcb.qcloud.la/image2.jpg?sign=9addaa6d81d6267187aa441221e0bb59&t=1611756844'],
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 2000,
    duration: 500,
     navbar:[
      {
        icon: "../../../images/shouye/market.png",
        text:"闲置"
      },
      {
        icon: "../../../images/shouye/news.png",
        text:"资讯"
      },
      
      {
        icon: "../../../images/shouye/map.png",
        text:"导览"
      },
      {
        icon: "../../../images/shouye/animals.png",
        text:"猫狗"
      },
      {
        icon:"../../../images/shouye/zixun.png",
        text:"社团"
      }
    ],
    //首页推荐
        // 是否显示下面的购物车
        HZL_isCat: 0,

        // 购物车的商品
        HZL_my_cat: [],
    
        // 购物车的数量
        HZL_num:0,
    
        // 左 => 右联动 右scroll-into-view 所需的id
        HZL_toView: null,
    
        // 右侧每类数据到顶部的距离（用来与 右 => 左 联动时监听右侧滚动到顶部的距离比较）
        HZL_eachRightItemToTop: [],
        HZL_leftToTop: 0,
    
        // 当前左侧选择的
        HZL_currentLeftSelect: null,   
     
        // 数据
        constants:[],
        //所要读取的数据库
        database:'constants',
        //数据库数量
        count: "",
        //下拉更新数据库数据个数
        nextPage: 0,
        //我的页面
        myPage: true,
  },
  onLoad: function (options) {
    // 初始化towerSwiper 传已有的数组名即可

    // 登录
    this.login();
    // 获取手机屏幕可用高度
    var that = this;
    this.userLoad()
    // 高度大小
    wx.getSystemInfo({
      success: function (res) {
        var HZL_height = res.windowHeight - 160
        var HZL_height1 = res.windowHeight - 110
        that.setData({
          HZL_height: HZL_height,
          HZL_height1: HZL_height1
        })
      }
    });
    that.setData({
      // 将请求的服务器数据赋值更新
      navH: app.globalData.navHeight,
    })

  },
  // 调用util.js中读取数据库函数
  userLoad: function () {
    var that = this;
      console.log('ask:', that.data.database);
      util.serachshouye(that);
          // 更新数据

  },

  onShow: function (options) {
    this.login();
  },

    // 登录操作(从云上获取用户信息)
    login: function(){
      //获取用户的openid并设置为全局变量
      wx.cloud.callFunction({
        name: 'login',
        complete: res => {
          console.log('callFunction test result: ', res)
          this.setData({
            openid: res.result.openid
          })
          util.getUserInCloud(this.data.openid);
        }
      })
    },

  // 首页推荐
    /**
   * 记录swiper滚动
   */
  HZL_swiperchange: function(e)
  {
    var that = this;
    that.setData({
      HZL_swiper_ID: e.detail.current,
    })
  },

  
  /**
   * 点击分类栏
   */
  HZL_categories:function(e)
  {
    var that = this;
    that.setData({
      HZL_swiper_ID: e.currentTarget.dataset.index
    })
  },


  /**
   * 获取每个右侧的 bar 到顶部的距离，
   * 用来做后面的计算。
   */
  HZL_getEachRightItemToTop: function ()
  {
    var obj = {};
    var totop = 0;
    // 右侧第一类肯定是到顶部的距离为 0
    obj[constants[0].id] = totop     
    // 循环来计算每个子类到顶部的高度
    for (let i = 1; i < (constants.length + 1); i++) {  
      totop += (RIGHT_BAR_HEIGHT + constants[i - 1].category.length * RIGHT_ITEM_HEIGHT)
      // 这个的目的是 例如有两类，最后需要 0-1 1-2 2-3 的数据，所以需要一个不存在的 'last' 项，此项即为第一类加上第二类的高度。
      obj[constants[i] ? constants[i].id : 'last'] = totop    
    }
    return obj
  },


  /**
   * 监听右侧的滚动事件与 HZL_eachRightItemToTop 的循环作对比
   * 从而判断当前可视区域为第几类，从而渲染左侧的对应类
   */
  right: function (e)
  {   
    for (let i = 0; i < this.data.constants.length; i++) {
      let left = this.data.HZL_eachRightItemToTop[this.data.constants[i].id]
      let right = this.data.HZL_eachRightItemToTop[this.data.constants[i + 1] ? this.data.constants[i + 1].id : 'last']
      if (e.detail.scrollTop < right && e.detail.scrollTop >= left) {
        this.setData({
          HZL_currentLeftSelect: this.data.constants[i].id,
          HZL_leftToTop: LEFT_ITEM_HEIGHT * i
        })
      }
    }
  },


  /**
   * 左侧类的点击事件，
   * 点击时，右侧会滚动到对应分类
   */
  left: function (e)
  {
    console.log(e)
    this.setData({
      
      HZL_toView: e.target.id || e.target.dataset.id,
      HZL_currentLeftSelect: e.target.id || e.target.dataset.id
    })
    console.log(e.target.id)
  },

  /**
   * 增加数量按钮
   */
  HZL_jia:function(e)
  {
    var index = e.currentTarget.dataset.index;
    var parentIndex = e.currentTarget.dataset.parentindex;
    var HZL_my_cat = this.HZL_my_jia(parentIndex, index)
    this.setData({
      HZL_num: this.data.HZL_num,
      HZL_my_cat: HZL_my_cat,
      constants: this.data.constants,
    })
  },


 
  /**
   * 封装加的方法
   */
  HZL_my_jia: function (parentIndex, index)
  {
    this.data.HZL_num++;
    var index = index;
    var parentIndex = parentIndex;
    var id = this.data.constants[parentIndex].category[index].category_id;
    var name = this.data.constants[parentIndex].category[index].category_name;
    var num = ++this.data.constants[parentIndex].category[index].num ;
    //弄一个元素判断会不会是重复的
    var mark = 'a' + index + 'b' + parentIndex + 'c' + '0' + 'd' + '0'
    var obj = { num: num, name: name,mark: mark, index: index, parentIndex: parentIndex };
    var HZL_my_cat = this.data.HZL_my_cat;
    HZL_my_cat.push(obj)

    var arr = [];
    //去掉重复的
    for (var i = 0; i < HZL_my_cat.length; i++) {
      if (obj.mark == HZL_my_cat[i].mark) {
        HZL_my_cat.splice(i, 1, obj)
      }
      if (arr.indexOf(HZL_my_cat[i]) == -1) {
        arr.push(HZL_my_cat[i]);
      }
    }
    return arr
  },


  /**
   * 封装减的方法
   */
  HZL_my_jian: function (parentIndex, index)
  {
    this.data.HZL_num--;
    var index = index;
    var parentIndex = parentIndex;
    var id = this.data.constants[parentIndex].category[index].category_id;
    var name = this.data.constants[parentIndex].category[index].category_name;
    var num = --this.data.constants[parentIndex].category[index].num;
    //弄一个元素判断会不会是重复的
    var mark = 'a' + index + 'b' + parentIndex + 'c' + '0' + 'd' + '0'
    var obj = { num: num, name: name, mark: mark, index: index, parentIndex: parentIndex };
    var HZL_my_cat = this.data.HZL_my_cat;
    HZL_my_cat.push(obj)

    var arr = [];
    //去掉重复的
    for (var i = 0; i < HZL_my_cat.length; i++) {
      if (obj.mark == HZL_my_cat[i].mark) {
        HZL_my_cat.splice(i, 1, obj)
      }
    }
    

    var arr1 = [];
    //当数量大于1的时候加
    for (var i = 0; i < HZL_my_cat.length; i++) {
      if (arr1.indexOf(HZL_my_cat[i]) == -1) {
        arr1.push(HZL_my_cat[i]);
        if (HZL_my_cat[i].num > 0) {
          arr.push(arr1[i])
        }
      }
    }

    return arr
  },
//点击跳转到动画
navbarTab: function (e) {
  var index = e.currentTarget.dataset.index;
  console.log(index)
  if(index == 0){
    wx.navigateTo({
      url: '/pages/Index/goods/goods?tab_id=0',
    })
  }else if(index == 1){
   wx.navigateTo({
     url: '/pages/Index/zixun/zixun',
   })
  }else if(index == 2){
    wx.navigateTo({
      url: '/pages/map/map',
    })
  }else if(index == 3){
    wx.navigateTo({
      url: '/pages/catanddog/catanddog',
    })
  }else if(index == 4){
    wx.navigateTo({
      url: '/pages/Community/Community',
    })
  }
},
click:function(e){
      // 判断当前用户是否为以注册用户
      var isRegistered=util.isRegistered()


      if(isRegistered)
      {
  console.log(e)
  var id = e.currentTarget.id
  var parentIndex = e.currentTarget.dataset.parentindex;
  console.log(e.currentTarget.id)
  console.log(parentIndex)
  console.log(this.data.constants[parentIndex].category[id])
  var post_data = JSON.stringify(this.data.constants[parentIndex].category[id])
  wx.navigateTo({
    // url: '../posttest/posttest?post_data=' + post_data
    url: '../pay/pay?post_data=' + post_data
  })
}
},

})
