var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
        //所要读取的数据库
        database: 'order',
        //数据库数量
        count: "",
        //数据库数据
        feed: [],
        //下拉更新数据库数据个数
        nextPage: 0,
  },
   //生命周期函数
   onLoad:function(){
    this.setData({
      userData: app.globalData.userCloudData,
      user_openid:app.globalData.userCloudData._openid
    })
    console.log(this.data.user_openid)
    this.userLoad()
  },
    // 调用util.js中读取数据库函数
    userLoad: function () {
      var that = this;
        console.log('ask:', that.data.database);
        util.searchmyorder(that);
    },
    confirme:function(e){
      var that = this
      var id = e.currentTarget.id
      var order_id = this.data.feed[id]._id
      console.log(order_id)
      wx.showModal({
        title:'确认送达',
        content: "确认该菜品已送达？"+this.data.feed[id].category_name,
        success (res) {
          if (res.confirm) {
             // 调用云函数修改用户信息
             wx.cloud.callFunction({
              name: 'Receiving',
              data: {
                order_id: order_id,
                Receiving: true
              }, success: function (res) {
                console.log("修改成功" + res)
                wx.redirectTo({
                  url: "../myorder/myorder?tab_id=" + 0
                })
              }, fail: function (res) {
                console.log(res)
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
    })
    },
    Historicalorder:function(){
      wx.navigateTo({
        url: '../Historicalorder/Historicalorder',
      })
    }
})