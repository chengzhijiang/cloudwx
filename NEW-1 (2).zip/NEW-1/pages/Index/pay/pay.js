const app = getApp()
Page({
  data: {
        //帖子信息
        post_data:{},
    categories: ["外卖", "堂食"],
      //送达时间
      express_time: "",
    //详细快递收件地址
    express_destination_detail: "",
        //快递收件地址
        express_destination: "北区生活部 男生宿舍 30号楼",
        express_region: "北区生活部",
        express_destination_1: "男生宿舍",
        express_destination_2: "30号楼",
            //可选快递收件地址
    chooseDestination: [["北区生活部", "南区生活部", "教学楼部"], ["男生宿舍", "女生宿舍"], ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"]],
    //所选快递收件地址下标
    destinationIndex: [0, 0, 0],
        //堂食或是外卖
        eatmode: true,
        currentData:0,
        //服务费
        Service:1.5,
        //合计价格
        allprice:"",
        //用户信息
        user_id: "",
        user_data: {},
        my_appointment:[],
        my_Takeaway:[],
        //用户输入的信息获取
        appointmentNotes:"",
        Takeawaynotes:""
  },
  onLoad:function(options){
    var post_data=JSON.parse(options.post_data)
    this.setData({
      post_data:post_data,
      currentData:0,
      allprice:Number(post_data.category_price)+this.data.Service,
      userData: app.globalData.userCloudData,
    })
    console.log(this.data.post_data)
    console.log(this.data.userData.phone)
  },
    // 选择快递送达时间
    timeChange(e) {
      this.setData({
        express_time: e.detail.value
      })
    },
      //选择快递收件地址
  destinationChange(e) {
    this.setData({
      destinationIndex: e.detail.value
    })
  },
      //选择快递收件地址
  destinationChange_column(e) {
    let data = {
      chooseDestination: this.data.chooseDestination,
      destinationIndex: this.data.destinationIndex
    };
    data.destinationIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.destinationIndex[0]) {
          case 0:
            data.chooseDestination[1] = ["男生宿舍", "女生宿舍"];
            data.chooseDestination[2] = ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"];
            break;
          case 1:
            data.chooseDestination[1] = ["男生宿舍", "女生宿舍"];
            data.chooseDestination[2] = ["一号宿舍楼","八号宿舍楼","九号宿舍楼","十号宿舍楼","十一号宿舍楼","十二号宿舍楼","十三号宿舍楼","十四号宿舍楼","十五号宿舍楼","十七号宿舍楼"];
            break;
          case 2:
            data.chooseDestination[1] = ["学院教学楼", "公共教学楼"];
            data.chooseDestination[2] = ["计算机与通信工程学院", "理学院", "管理学院", "国际工商学院","聋人工学院","材料学院","自动化学院","艺术学院","工程训练中心","语言文化学院","自动化学院及机械工程学院","化学化工学院","电子信息工程学院","环境科学与安全工程学院"];
            break;
        }
        data.destinationIndex[1] = 0;
        data.destinationIndex[2] = 0;
        break;
      case 1:
        switch (data.destinationIndex[0]) {
          case 0:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"];
                break;
              case 1:
                data.chooseDestination[2] = ["20号宿舍楼", "21号宿舍楼", "22号宿舍楼", "26号宿舍楼", "27号宿舍楼"];
                break;
              // 后面需要补上中区南区等位置
              case 2:case 3:case 4:case 5:
                data.chooseDestination[2]=[]
                break;
            }
            break;
          case 1:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["一号宿舍楼","八号宿舍楼","九号宿舍楼","十号宿舍楼","十一号宿舍楼","十二号宿舍楼","十三号宿舍楼","十四号宿舍楼","十五号宿舍楼","十七号宿舍楼"];
                break;
              case 1:
                data.chooseDestination[2] = ["二号宿舍楼", "三号宿舍楼", "四号宿舍楼", "五号宿舍楼","六号宿舍楼","七号宿舍楼","十六号宿舍楼"];
                break;
            }
            break;
          case 2:
            switch (data.destinationIndex[1]) {
              case 0:
                data.chooseDestination[2] = ["计算机与通信工程学院", "理学院", "管理学院", "国际工商学院","聋人工学院","材料学院","自动化学院","艺术学院","工程训练中心","语言文化学院","自动化学院及机械工程学院","化学化工学院","电子信息工程学院","环境科学与安全工程学院"];
                break;
              case 1:
                data.chooseDestination[2] = ["一号教学楼", "二号教学楼", "三号教学楼", "四号教学楼","五号教学楼","六号教学楼","二十七号教学楼","28号教学楼"];
                break;
            }
            break;
        }
        data.destinationIndex[2] = 0;
        break;
    }
    this.setData(data);
    this.setData({
      express_destination: this.data.chooseDestination[0][this.data.destinationIndex[0]] + " " + this.data.chooseDestination[1][this.data.destinationIndex[1]] + " " + this.data.chooseDestination[2][this.data.destinationIndex[2]],
      express_region: this.data.chooseDestination[0][this.data.destinationIndex[0]],
      express_destination_1: this.data.chooseDestination[1][this.data.destinationIndex[1]],
      express_destination_2: this.data.chooseDestination[2][this.data.destinationIndex[2]],
    });
  },
    //订餐须知
    openProtocol(e) {
      this.setData({
        warning: "pay",
        modalName: "Modal",
      })
    },
      //隐藏模态窗口
  hideModal(e) {
    this.setData({
      modalName: null,
      warning:""
    })
  },
    //是否同意协议
    checkboxChange() {
      this.setData({
      agree: !this.data.agree
      })
      console.log("agree?",this.data.agree)
    },
        //滑动更新主导航栏下标
        categoriesTab: function (e) {
          this.setData({
            currentData: e.currentTarget.dataset.index
          })
          console.log(this.data.currentData)
          if(this.data.currentData == 0){
            this.setData({
              eatmode:true,
              Service:1.5,
              allprice:Number(this.data.post_data.category_price)+this.data.Service
            })
            console.log(this.data.Service)
          }else if(this.data.currentData == 1){
            this.setData({
              eatmode:false,
            })
            console.log(this.data.Service)
          }
        },
        // 预约按钮
        Makeappointment:function(e){
          var appointment = {};
          this.setData({
            appointmentNotes:e.detail.value.appointmentNotes,
            category_price:this.data.post_data.category_price,
            category_name:this.data.post_data.category_name,
            express_time:this.data.express_time,
            catererphone:this.data.user_data.phone
          })
          //检查是否有空值
          this.checkappointmentInfo()
          if(this.data.appointmentMode){
          var appointment = { appointmentNotes: this.data.appointmentNotes, category_price: this.data.post_data.category_price, express_time: this.data.express_time,catererphone: this.data.userData.phone,category_name:this.data.post_data.category_name};
          var my_appointment = this.data.my_appointment;
          my_appointment.push(appointment)
          console.log(my_appointment)
          var post_data = JSON.stringify(this.data.my_appointment[0])
          wx.navigateTo({
            // url: '../posttest/posttest?post_data=' + post_data
            url: '../../payment/payment?post_data=' + post_data
          })
        }
        },
        Payprice:function(e){
          var Takeaway = {};
          this.setData({
            Takeawaynotes:e.detail.value.Takeawaynotes,
            category_price:this.data.allprice,
            category_name:this.data.post_data.category_name,
            express_destination:this.data.express_destination,
            express_time:this.data.express_time,
            catererphone:this.data.user_data.phone,
            type:this.data.express_region,
          })
          //检查是否有空值
          this.checkTakeawayInfo()
          if(this.data.TakeawayMode){
          var Takeaway = { Takeawaynotes: this.data.Takeawaynotes, category_price: this.data.allprice, express_time: this.data.express_time,catererphone: this.data.userData.phone,express_destination : this.data.express_destination,category_name:this.data.post_data.category_name,type:this.data.express_region};
          var my_Takeaway = this.data.my_Takeaway;
          my_Takeaway.push(Takeaway)
          console.log(my_Takeaway)
          var post_data = JSON.stringify(this.data.my_Takeaway[0])
          wx.redirectTo({
            // url: '../posttest/posttest?post_data=' + post_data
            url: '../../payment/payment?post_data=' + post_data
          })
        }
        },
        //检查是否有空值
  checkTakeawayInfo:function() {
    if (this.data.express_time == "") {
      this.setData({
        warning: "请选择预约时间"
      })
    }else if (this.data.express_destination == "") {
      this.setData({
        warning: "请选择收获地址"
      })
    } else if (this.data.Takeawaynotes == "") {
      this.setData({
        warning: "请填写外卖备注"
      })
    }else {
      this.setData({
        warning: "完成",
        display:false,
        TakeawayMode: true,
      })
    }
    // 有错误即弹框提示
    if(!this.data.infoMode){
      this.setData({
        modalName: "Modal1",
      })
    }
  },
          //检查是否有空值
          checkappointmentInfo:function() {
            if (this.data.express_time == "") {
              this.setData({
                warning: "请选择预约时间"
              })
            }else if (this.data.appointmentNotes == "") {
              this.setData({
                warning: "请填写外卖备注"
              })
            }else {
              this.setData({
                warning: "完成",
                display:false,
                appointmentMode: true,
              })
            }
            // 有错误即弹框提示
            if(!this.data.infoMode){
              this.setData({
                modalName: "Modal1",
              })
            }
          },
       //隐藏模态窗口
       modalChange(e) {
        this.setData({
          modalName: null
        })
      },
})