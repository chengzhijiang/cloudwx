var util = require('../../../utils/util.js')
const app = getApp()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
        tanchuang_show:false,
        //背景图片
        beijingimages:[],
        //头像列表
        swiperList:[],
        //用户信息
        user_id: "",
        user_data: {},
        luntan_id:"",
        //所要读取的数据库
        database: 'luntan',
        //数据库数量
        count: "",
        //数据库数据
        feed: [],
        //下拉更新数据库数据个数
        nextPage: 0,
        images:[],
  },
// 更换背景图片
changebeijing:function(){
  var that = this;
    wx.showActionSheet({
      itemList: ['更换背景图片'],
      success(res){  
        if(res.tapIndex==0){
          wx.chooseImage({
            count: 1, //最多可以选择的图片张数
            sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: res => {
              that.setData({
                beijingimages:that.data.beijingimages.concat(res.tempFilePaths)
              })
              console.log(that.data.beijingimages)
              that.uploadbeijingImages()
            }
          });
        }
      }
    })
  },
  //跳转到发布信息界面
  xxiangji(){
    wx.showActionSheet({
      itemList: ['发布图文'],
      success (res) {
        console.log(res.tapIndex)
        if(res.tapIndex==0){
          wx.navigateTo({
            url: '/pages/Post/article/article',
          })
        }
      },
    })
  },
  show_tanchuang(){
    var tanchuang_show=!this.data.tanchuang_show
    this.setData({
      tanchuang_show
    })
  },
  //生命周期函数
  onLoad:function(){
    this.setData({
      swiperList: app.globalData.swiperList,
      user_id:this.data.feed._openid,
      userData: app.globalData.userCloudData,
    })
    this.getUserData()
    this.userLoad()
  },

  // 调用util.js中读取数据库函数
  userLoad: function () {
    var that = this;
      console.log('ask:', that.data.database);
      util.serachluntan(that);
  },

  // 获取帖子主人的信息
  getUserData:function(){
    const db = wx.cloud.database()
    // 查询当前帖子的主人信息
    db.collection('users').where({
      _openid:this.data.user_id
    }).get({
      success: res => {
        this.setData({
          luntanuser_data:res.data[0]
        })
        console.log('[数据库] [查询记录] 成功: ', this.data.luntanuser_data)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    });
  },
    // 获取帖子主人的信息
  getUserData:function(){
    console.log(this.data.user_id)
    const db = wx.cloud.database()
    // 查询当前帖子的主人信息
    db.collection('users').where({
      _openid:this.data.user_id
    }).get({
      success: res => {
        this.setData({
          luntanuser_data:res.data[0]
        })
        console.log('[数据库] [查询记录] 成功: ', this.data.luntanuser_data)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    });
  },
    //用户点击放大图片
    handleImagePreview:function(e) {
      console.log(e)
      var idx = e.target.dataset.idx
      var index = e.target.dataset.imageid
      var images = this.data.feed[idx].images
      console.log(images)
      wx.previewImage({
        current: images[index],  //当前预览的图片
        urls: images,  //所有要预览的图片
      })
    },
    //将更换完的背景图上传到数据库
    uploadbeijing:function() {
      console.log("上传数据")
      const db = wx.cloud.database()
      db.collection("users").doc(app.globalData.userCloudData._id).update({
        data: {
          "beijingimages":this.data.luntan_beijingimages
        },
        success: function (res) {
          //成功上传后提示信息
          console.log("更换背景成功")
          wx.showLoading({
            title: '更换背景成功',
            icon: 'success',
            duration: 1000,
          })
          this.onLoad()
        }
      })
    },
     //上传背景图片信息
 uploadbeijingImages:function(){
  var beijingimages=this.data.beijingimages
  //先添加到这一变量,在最后一个再改变this.data.中的animals_LOGOimages
  var luntan_beijingimages=[]
  beijingimages.forEach(item => {
    console.log(item)
    wx.cloud.uploadFile({
      cloudPath: "luntan_beijingimages/"+item.substring(item.length-20), // 上传至云端的路径
      filePath: item, // 小程序临时文件路径
      success: res => {
        // 返回文件 ID
        console.log(res.fileID)
        luntan_beijingimages.push(res.fileID)
        console.log(luntan_beijingimages)

        //获取所有图片在云端的位置后上传到数据库
        if(luntan_beijingimages.length===beijingimages.length){
          //将局部变量赋给this.data
          this.setData({
            luntan_beijingimages:luntan_beijingimages
          })
          console.log(this.data.luntan_beijingimages)
          //隐藏上传提示
          wx.hideLoading()
          this.uploadbeijing()
        }
      },
      fail: console.error
    })
  });
},
      //检查用户是否已经注册(决定点击跳转到的页面)
      checkUser:function(){
        console.log(this.data.userData)
        if (app.globalData.userCloudData.approve==="0") {
          wx.navigateTo({
            url:"../../renzheng/Mine/registered/registered"
          })
        }else {
          wx.navigateTo({
            url: "../../renzheng/Mine/userInfo/userInfo"
          })
        }
      },
})