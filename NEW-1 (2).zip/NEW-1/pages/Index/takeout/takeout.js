var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: ["全部","北区生活部", "南区生活部", "教学楼部"],
    //酬金
    price: ["全部","酬金由低到高","酬金由高到低"],
     //全部校区
     allRegion1: {"全部":{"":[""]},"北区生活部":{"全部":[""],"男生宿舍":["全部","24号宿舍楼","28号宿舍楼", "29号宿舍楼","30号宿舍楼", "31号宿舍楼", "其他"],"女生宿舍":["全部","20号宿舍楼", "21号宿舍楼", "22号宿舍楼", "26号宿舍楼", "27号宿舍楼"],},"南区生活部":{"全部":[""],"男生宿舍":["全部","一号宿舍楼","八号宿舍楼","九号宿舍楼","十号宿舍楼","十一号宿舍楼","十二号宿舍楼","十三号宿舍楼","十四号宿舍楼","十五号宿舍楼","十七号宿舍楼"],"女生宿舍":["全部","二号宿舍楼", "三号宿舍楼", "四号宿舍楼", "五号宿舍楼","六号宿舍楼","七号宿舍楼","十六号宿舍楼"]},"教学楼部":{"全部":[""],"学院教学楼":["全部","计算机与通信工程学院", "理学院", "管理学院", "国际工商学院","聋人工学院","材料学院","自动化学院","艺术学院","工程训练中心","语言文化学院","自动化学院及机械工程学院","化学化工学院","电子信息工程学院","环境科学与安全工程学院"],"公共教学楼":["一号教学楼", "二号教学楼", "三号教学楼", "四号教学楼","五号教学楼","六号教学楼","二十七号教学楼","28号教学楼"]}},
         //全部日期
    allTime1: ["全部", "今天", "明天", "后天"],
            //所要读取的数据库
            database: 'order',
            //数据库数量
            count: "",
            //数据库数据
            feed: [],
            //下拉更新数据库数据个数
            nextPage: 0,
            currentData:0,
  },
  onLoad:function(){
    this.setData({
      userData: app.globalData.userCloudData,
      user_openid: app.globalData.userCloudData._openid,
    })
    console.log(this.data.userData._openid)
    this.userLoad()
  },
      // 调用util.js中读取数据库函数
      userLoad: function () {
        var that = this;
          console.log('ask:', that.data.database);
          util.searchallorder(that);
      },
    //滑动更新主导航栏下标
    categoriesTab: function (e) {
      var that = this;
      this.setData({
        currentData: e.currentTarget.dataset.index,
      })
      console.log(this.data.currentData)
      var currentData = this.data.currentData

    },
        //更新副导航栏下标
        categoriesChange: function (e) {
          let current = e.detail.current;
          let source = e.detail.source
          //console.log(source);
          // 这里的source是判断是否是手指触摸 触发的事件
          if (source === 'touch') {
            this.setData({
              currentData: current
            })
            console.log(this.data.currentData)
          }
        },
      // 拖到最下面更新数据
  lower: function (e) {
    wx.showNavigationBarLoading();
    var that = this;
    util.searchmyorder(that);
    console.log("lower")
  },

  confirme:function(e){
    var that = this
    var id = e.currentTarget.id
    var order_id = this.data.feed[id]._id
    var userData_openid = this.data.userData._openid
    console.log(order_id)
    wx.showModal({
      title:'确认接单',
      content: "确认接单？"+this.data.feed[id].category_name,
      success (res) {
        if (res.confirm) {
          // 调用云函数修改用户信息
          wx.cloud.callFunction({
            name: 'Takeorders',
            data: {
              order_id:order_id,
              Delivery:true,
              Deliveryboy: userData_openid
            }, success: function (res) {
              console.log("修改成功" + res)
              wx.redirectTo({
                url: "../takeout/takeout?tab_id=" + 0
              })
            }, fail: function (res) {
              console.log(res)
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
  })
  },
})