var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: ["理工助手", "校园资讯", "猫狗日记"],
    //所要读取的数据库
    database: 'zixun',
    //数据库数量
    count: "",
    //数据库数据
    feed: [],
    //下拉更新数据库数据个数
    nextPage: 0,
    currentData: 0,
  },

    //滑动更新主导航栏下标
    categoriesTab: function (e) {
      this.setData({
        // currentIndex: e.currentTarget.dataset.index
        currentData: e.currentTarget.dataset.index
      })
      console.log(this.data.currentData)
    },
        //更新副导航栏下标
        categoriesChange: function (e) {
          let current = e.detail.current;
          let source = e.detail.source
          //console.log(source);
          // 这里的source是判断是否是手指触摸 触发的事件
          if (source === 'touch') {
            this.setData({
              currentData: current
            })
            console.log(this.data.currentData)
          }
        },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 根据点击查找数据库
    this.userLoad();
  },
  // 调用util.js中读取数据库函数
  userLoad: function () {
    var that = this;
      console.log('ask:', that.data.database);
      util.serachzixuninfo(that);
  },

  zixunhome: function (e) {
    var index = e.currentTarget.id;
    console.log(index)
    var post_data = JSON.stringify(this.data.feed[index])
    console.log(post_data)
    wx.navigateTo({
      // url: '../posttest/posttest?post_data=' + post_data
      url: '../contact_zixun/contact_zixun?post_data=' + post_data
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})