// pages/article/article.js
var util = require('../../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH: 0,
    theme: {
      color: '#1890FF',
      tabColor: '#333' || '#20ACAB',
    },
    topic:{
      sorts:
      ["表白交友", "疑问互答","相约学习", "实物招领", "趣事分享"],

    },
    topic1:"",
    content:"",
    location: "",
    imageList: [],
    video:{},
    anonymous: false,
    iamges:[],
    type:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    util.isRegistered()
    this.setData({
      head_index: app.globalData.userCloudData.head_index,
      nick_name: app.globalData.userCloudData.nick_name
    })
    console.log(this.data.head_index)
    console.log(this.data.nick_name)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  bindContent: function(e) {
    this.setData({content: e.detail.value})
  },

  // 清空照片或者图片
  clearInput: function(name){
    if (name != 'imageList') {
      this.setData({ imageList: [] })
    }
    if (name != 'video') {
      this.setData({ video: {} })
    }
  },
  
  // 选择照片
  chooseImage: function(e){
    var that = this;
    let surplus = 9 - this.data.imageList.length
    wx.chooseImage({
      count: surplus,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        that.clearInput("imageList");
        that.addNewImage(res.tempFilePaths);
       
        wx.showToast({
          title: '上传成功！',
        })
      }
    })
  },

  addNewImage(imagePath){
    var list = this.data.imageList
    list = list.concat(imagePath)
    this.setData({
      imageList: list
    })
  },

  thisImage:function(e){
    console.log(e)
    let index = e.currentTarget.dataset.imageid;
    let list = this.data.imageList;
    wx.previewImage({
      urls: list,
      current: list[index]
    })
  },

  deleteImage: function(e){
    let index = e.currentTarget.dataset.imageid;
    let list = this.data.imageList;
    list.splice(index, 1)
    this.setData({
      imageList: list
    })
  },

  // 视频相关
  chooseVideo: function(e){
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: 'back',
      success:(res)=>{
        this.clearInput("video")
        this.setData({
          video:res
        });
        wx.showToast({
          title: '上传成功！',
        })
      }
    })
  },

  deleteVideo: function(e){
    this.setData({
      video:{}
    })
  },

 
  chooseLocation:function(e){
    wx.showLoading({
      title: '正在加载',
    })
    wx.chooseLocation({
      success:(res)=>{
        wx.hideLoading({
          success: (res) => {},
        })
        let address = ''; 
        let locName = res.name;
        let city = this.getCityName(res.address)
        if(city){
          address = city + '·' + locName
        }else{
          address = locName
        }
        this.setData({
          location: address
        })
      },
      fail:(res)=>{
        wx.hideLoading({
          success: (res) => {},
        })
      }
    })
  },
  // 是否匿名
  postStatus:function(e){
    this.setData({
      anonymous: !this.data.anonymous
    },()=>{
      console.log(this.data.anonymous)
    })
  },


  // 发布的类型
  clickTag:function(e){
    console.log(e)
    let topicId = e.target.dataset.topicid;
    let topic = this.data.topic;
    topic.selected = topicId;
    this.setData({
      type:this.data.topic.sorts[topicId],
      topic
    })

  },

// 发布按钮
forsubmit: function(){
    if(this.data.content ==''){
      wx.showToast({
        icon: 'none',
        title: '亲！写点东西吧',
      })
      }else if(this.data.type==""){
        wx.showToast({
          icon: 'none',
          title: '亲！请选择发布类型',
        })
      }else {
        this.submit()
      }
   
  } ,

  


  submit: function(){
    var date=new Date()
    let promiseArr = [];
    var that = this;
    let anonymous = this.data.anonymous;
    this.data.images = [];
    console.log(anonymous)
   
      for(var i=0;i<that.data.imageList.length;i++){
        // 将图片上传至云存储空间
        let promise = new Promise((resolve, reject) => {
       wx.cloud.uploadFile({
         // 指定要上传的文件的小程序临时文件路径
         cloudPath: 'luntan/' +Date.now()+i+'.png',
         filePath: that.data.imageList[i],
         // 成功回调
         success: res => {
          resolve(res);
           that.data.images.push(res.fileID)
           console.log(that.data.images)
         },
         fail: function (error) {
          reject(error);
         },
         complete: function (res) {
        },
       })
      });
      promiseArr.push(promise)

      }
      Promise.all(promiseArr).then((result) => {
        console.log(that.data.images)
      const db = wx.cloud.database();
      var date = util.formatTime2(new Date().getTime() / 1000, 'Y年M月D日 h:m:s')
      db.collection('luntan').add({
        data: {
          "content":this.data.content,
          "images":that.data.images,
          "anonymou":this.data.anonymous ,           
          "date":new Date().getTime(),
          "time":date,
          "type":this.data.type,
          "head_index":this.data.head_index,
          "nick_name":this.data.nick_name
        }}).then(res => {
          wx.showToast({
            title: '成功',
            success: function (){
              wx.switchTab({
                url:"/pages/Index/secound/secound?tab_id=" + 0
              })
            }
          })        
        })

    })
  },

// 取消发布
cancel:function(){
wx.navigateBack({
  delta:1,
})
},
})
