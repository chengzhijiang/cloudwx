var util = require('../../../utils/util')
var app = getApp()

Page({
  data: {
  // 社团类别
    Community_type:"",
    // 可选社团类别
    choosetype: ["社团活动", "院级", "校级", "市级","省级","赛区级","国家级"],
  // 所选社团类别下标
    type_index:0,
    //活动类型
    Community_activity_type:"",
    //可选活动类型
    chooseactivitytype:["教育活动","科技活动","公益活动","组织活动","文娱活动","体育活动","比赛竞技"],
    //所选活动类型下标
    type_activity_index:0,
// 登记用户的formId在帖子数据库上
formId:"",
//存放照片在手机中的位置
images:[],

    //警告
    warning: "",
    //检验填写信息是否完整(boolean)
    infoMode: false,
    // 辨别用户第几次点击发布
    display:true,
    //判断用户是否更改姓名
    changeName: false,
    //用户所上传信息
    Community_mainname:"",
    Community_Organizer:"",
    Community_activitycharge:"",
    Community_activitypoint:"",
    Community_maingrades:"",
    Community_faceperson:"",
    //快递取件人姓名
    Community_name: "",
    ori_Community_name: "",
    //快递取件人微信号
    Community_wechat: "",
    ori_Community_wechat: "",
    //快递取件人手机号
    Community_phone: "",
    ori_Community_phone: "",
    //快递取件码
    Community_code: "",
    //详细说明
    Community_note: "",

  },
      //判断社团的类型
      typechange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          type_index: e.detail.value,
          Community_type:this.data.choosetype[e.detail.value]
        })
      },
       //判断活动的类型
       Activitytypechange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          type_index: e.detail.value,
          Community_activity_type:this.data.chooseactivitytype[e.detail.value]
        })
      },
  onLoad: function (options) {
    // 判断当前用户是否为以注册用户
    util.isRegistered()
    this.setData({
      Community_wechat: app.globalData.userCloudData.wechat_id,
      Community_phone: app.globalData.userCloudData.phone,
      ori_Community_name: app.globalData.userCloudData.real_name,
      ori_Community_wechat: app.globalData.userCloudData.wechat_id,
      ori_Community_phone: app.globalData.userCloudData.phone,
    })
  },
  //统计文本域字数
  bindInput(e) {
    var inputLength = e.detail.value.length;
    this.setData({
      inputLength: inputLength,
    })
  },

  // 提示用户选择订阅信息
  showMessageModal:function(){
    var that=this
    wx.showModal({
      title: '提示',
      content: '请允许我们向你发送快递通知,方便追踪快递走向',
      success (res) {
        // that.getMessage();
        that.getMessage();
      }
    })

  },
  // 弹框获取发送订阅消息权限
  getMessage:function(){
    var that= this
    wx.requestSubscribeMessage({
     tmplIds: ['l3MDM8SSqxszV1FJ-TY-LxJTKo5m0Djf--ZVXrWLbzA'],
     complete(res){
           // 先将照片上传再上传数据库

      if (that.data.images.length === 0) {
        that.uploadData()
      } else {
        that.uploadImages()
      }
    
   // 判断是否修改姓名
       if (that.data.changeName) {
         that.changeUsername();
       }
     }
   })

 },

  // 检查用户个人信息
  checkUserInfo:function(e){
    if (e.detail.value.Community_name != "") {
      this.setData({
        Community_name: e.detail.value.Community_name,
        changeName: true,
      })
    } else if (this.data.ori_Community_name != null) {
      this.setData({
        Community_name: this.data.ori_Community_name
      })
    }

    if (e.detail.value.Community_wechat != "") {
      this.setData({
        Community_wechat: e.detail.value.Community_wechat
      })
    } else {
      this.setData({
        Community_wechat: this.data.ori_Community_wechat
      })
    }

    if (e.detail.value.Community_phone != "") {
      this.setData({
        Community_phone: e.detail.value.Community_phone
      })
    } else {
      this.setData({
        Community_phone: this.data.ori_Community_phone
      })
    }

  },

  //检查是否有空值
  checkCommunityInfo:function() {
   if (this.data.Community_mainname == "") {
      this.setData({
        warning: "请填写社团名称"
      })
    } else if (this.data.Community_activity_type == "") {
      this.setData({
        warning: "请选择活动类型"
      })
    } else if (this.data.Community_activitycharge == "") {
      this.setData({
        warning: "请填写活动负责人"
      })
    } else if (this.data.Community_type == "") {
      this.setData({
        warning: "请填写活动等级"
      })
    }else if (this.data.Community_activitypoint == "") {
      this.setData({
        warning: "请填写主要活动地点"
      })
    } else if (this.data.Community_maingrades == "") {
      this.setData({
        warning: "请简要描述活动"
      })
    } else if (this.data.Community_name == "") {
      this.setData({
        warning: "联系人姓名不能为空",
      })
    }
    // 先不检验微信号的正确性（注册于个人信息那里需要修改）
    // else if (this.data.Community_wechat == "" || (!(/^[a-zA-Z]([-_a-zA-Z0-9]{5,19})$/.test(this.data.Community_wechat)))) {
    //   this.setData({
    //     warning: "请输入正确的微信号",
    //   })
    // }
    else if (this.data.Community_phone == "" || (!(/^1(3|4|5|6|7|8|9)\d{9}$/.test(this.data.Community_phone)))) {
      this.setData({
        warning: "请输入正确的手机号码"
      })
    } else if (this.data.images.length == 0) {
      this.setData({
        warning: "请至少上传一张活动宣传图",
      })
    }else {
      this.setData({
        warning: "发布成功",
        display:false,
        infoMode: true,
      })
    }
    // 有错误即弹框提示
    if(!this.data.infoMode){
      this.setData({
        modalName: "Modal",
      })
    }
  },

  //验证微信号,以及得到用户所写信息
  uploadPost(e) {
    this.setData({
      Community_mainname:e.detail.value.Community_mainname,
      Community_Organizer:e.detail.value.Community_Organizer,
      Community_activitycharge:e.detail.value.Community_activitycharge,
      Community_activitypoint:e.detail.value.Community_activitypoint,
      Community_maingrades:e.detail.value.Community_maingrades,
      Community_type:this.data.Community_type,
      Community_activity_type:this.data.Community_activity_type,
      Community_faceperson:e.detail.value.Community_faceperson
    })
    this.checkUserInfo(e);
    //检查是否有空值
    this.checkCommunityInfo();

    // 填写信息完整则准备上传
    if(this.data.infoMode){
      this.showMessageModal();
    }
  },


  //上传数据
  uploadData: function () {
    // 送达截止时间戳
    var date = new Date()
    var time = util.formatTime2(new Date().getTime() / 1000, 'Y年M月D日 h:m:s')
    const db = wx.cloud.database()
    db.collection("CommunityActivity").add({
      data: {
        "Community_activity_mainname":this.data.Community_mainname,
        "type":this.data.Community_type,
        "Community_activity_type":this.data.Community_activity_type,
         "Community_Organizer":this.data.Community_Organizer,
         "Community_activitycharge":this.data.Community_activitycharge,
         "Community_activitypoint":this.data.Community_activitypoint,
         "Community_maingrades":this.data.Community_maingrades,
         "Community_images":this.data.Community_images,
         "Community_faceperson":this.data.Community_faceperson,
         "real_name": this.data.Community_name,
         "wechat_id": this.data.Community_wechat,
         "phone": this.data.Community_phone,
         "date": date,
         "Time":time,
         "contact":this.data.contact_way,
         "Community_type":"活动"
      },
      success(res) {
        console.log("插入成功")
        wx.redirectTo({
          url: "../../Admin/huodong/huodong?tab_id=" + 0
        })

      }
    })
  },

  //更新用户名
  changeUsername:function() {
    console.log("上传数据")
    const db = wx.cloud.database()
    db.collection("users").doc(app.globalData.userCloudData._id).update({
      data: {
        "real_name": this.data.Community_name,
      },
      success: function (res) {
        //成功上传后提示信息
        console.log("上传成功")
        wx.showLoading({
          title: '成功上传',
          icon: 'success',
          duration: 1000,

        })
        wx.navigateBack({})
      }
    })
  },
 //选择图片
 chooseImage: function(e) {
  var that = this;
  if (that.data.images.length < 3) {
    wx.chooseImage({
      count: 3, //最多可以选择的图片张数
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        this.setData({
          images:this.data.images.concat(res.tempFilePaths)
        })
        console.log(this.data.images)
      }
    });
  } else {
    wx.showToast({
      title: "图片限传三张！",
      icon: 'none',
      duration: 2000,
      mask: true,
    });
  }
},


//用户点击放大图片
handleImagePreview:function(e) {
  var index = e.target.dataset.index
  var images = this.data.images
  wx.previewImage({
    current: images[index],  //当前预览的图片
    urls: images,  //所有要预览的图片
  })
},


//点击删除移除照片
removeImage:function(e) {
  var index = e.target.dataset.index
  //删除指定位置的照片
  var images=this.data.images
  images.splice(index,1)
  this.setData({
    images:images
  })
  console.log(index)
  console.log(this.data.images)
},

//隐藏模态窗口
modalChange(e) {
  this.setData({
    modalName: null
  })
},

//上传图片
uploadImages:function(){
  var images=this.data.images
  //先添加到这一变量,在最后一个再改变this.data.中的Community_images
  var Community_images=[]
  images.forEach(item => {
    console.log(item)
    wx.cloud.uploadFile({
      cloudPath: "Community_activityimages/"+item.substring(item.length-20), // 上传至云端的路径
      filePath: item, // 小程序临时文件路径
      success: res => {
        // 返回文件 ID
        console.log(res.fileID)
        Community_images.push(res.fileID)
        console.log(Community_images)

        //获取所有图片在云端的位置后上传到数据库
        if(Community_images.length===images.length){
          //将局部变量赋给this.data
          this.setData({
            Community_images:Community_images
          })
          console.log(this.data.Community_images)
          //隐藏上传提示
          wx.hideLoading()
          this.uploadData()
        }
      },
      fail: console.error
    })
  });
},
})