var util = require('../../../utils/util')
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: ["新增首页商家", "增加商家菜品"],
    currentData:1,
    shangjia:{},
      // 商家类别
      Merchants_type:"",
      // 可选商家类别
      choosetype: ["商户", "每日推荐", "水果配送"],
      //所属商户
      Canteen_type:"",
      //可选商户类别
      Canteentype: [],
      //用户填写的信息
      Merchants_name:"",
      describe:"",
      Merchants_Menu_name:"",
      Merchants_Menu_price:"",
      Menu_name:"",
      Menu_price:"",
          //存放照片在手机中的位置
    Menuimages:[],
    //LOGO存放在手机中的位置
    Merchantsimages:[],
    //警告
    warning: "",
    //检验填写信息是否完整(boolean)
    infoMode: false,
    // 辨别用户第几次点击发布
    display:true,
            // 数据
            constants:[],
            //所要读取的数据库
            database:'constants',
            //数据库数量
            count: "",
            //下拉更新数据库数据个数
            nextPage: 0,
            //我的页面
            myPage: true,

  },
  onLoad:function(){
    //查询数据库
    this.userLoad()
  },
    // 调用util.js中读取数据库函数
    userLoad: function (e) {
      var that = this;
        console.log('ask:', that.data.database);
        util.serachMerchants(that);
    },
  uploadMenu(e){
    this.setData({
      Menu_name:e.detail.value.Menu_name,
      Menu_price:e.detail.value.Menu_price
    })
    console.log('321',this.data.constants)
    console.log('213',this.data.Canteentype)
    //检查是否有空值
    this.checkMenuInfo()
    if(this.data.infoMode){
      this.uploadMenuImages();
    }
    
  },
  uploadMerchants(e){
    this.setData({
      Merchants_name:e.detail.value.Merchants_name,
      describe:e.detail.value.describe,
      Merchants_Menu_name:e.detail.value.Merchants_Menu_name,
      Merchants_Menu_price:e.detail.value.Merchants_Menu_price,
    })
    //检查是否有空值
    this.checkMerchantsInfo()
        // 填写信息完整则准备上传
        if(this.data.MerchantsMode){
          this.uploadMerchantsData();
        }
  },
    // 提示用户选择订阅信息
    showMessageModal:function(){
      var that=this
      wx.showModal({
        title: '提示',
        content: '请允许我们向你发送快递通知,方便追踪快递走向',
        success (res) {
          // that.getMessage();
          that.getMessage();
        }
      })
    },
     // 弹框获取发送订阅消息权限
  getMessage:function(){
    var that= this
    wx.requestSubscribeMessage({
     tmplIds: ['l3MDM8SSqxszV1FJ-TY-LxJTKo5m0Djf--ZVXrWLbzA'],
     complete(res){
           // 先将照片上传再上传数据库
      if (that.data.Merchantsimages.length === 0) {
        that.uploadMerchantsData()
      } else {
        that.uploadMerchantsImages()
      }
     }
   })
 },

    //检查准备上传的菜品是否有空值
    checkMenuInfo:function() {
      if (this.data.Canteen_type == "") {
        this.setData({
          warning: "请选择所属商户"
        })
      }else if (this.data.Menu_name == "") {
        this.setData({
          warning: "请填写菜品名称"
        })
      }else if (this.data.Menu_price == "") {
        this.setData({
          warning: "请填写菜品价格"
        })
      }else if (this.data.Menuimages.length == 0) {
        this.setData({
          warning: "请上传菜品图片"
        })
      }else {
        this.setData({
          warning: "发布成功",
          display:false,
          infoMode: true,
        })
      }
      // 有错误即弹框提示
      if(!this.data.infoMode){
        this.setData({
          modalName: "Modal",
        })
      }
    },
      //检查是否有空值
  checkMerchantsInfo:function() {
    if (this.data.Merchants_type == "") {
      this.setData({
        warning: "请选择商家类别"
      })
    }else if (this.data.Merchants_name == "") {
      this.setData({
        warning: "请填写商家名称"
      })
    } else if (this.data.describe == "") {
      this.setData({
        warning: "请填写商家描述"
      })
    }else {
      this.setData({
        warning: "发布成功",
        display:false,
        MerchantsMode: true,
      })
    }
    // 有错误即弹框提示
    if(!this.data.infoMode){
      this.setData({
        modalName: "Modal",
      })
    }
  },
  //选择图片
 chooseMenuImage: function(e) {
  var that = this;
  if (that.data.Menuimages.length < 1) {
    wx.chooseImage({
      count: 1, //最多可以选择的图片张数
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        this.setData({
          Menuimages:this.data.Menuimages.concat(res.tempFilePaths)
        })
        console.log(this.data.Menuimages)
      }
    });
  } else {
    wx.showToast({
      title: "图片限传一张！",
      icon: 'none',
      duration: 2000,
      mask: true,
    });
  }
},
   //上传菜品图片
   uploadMenuImages:function(){
    var Menuimages=this.data.Menuimages
    //先添加到这一变量,在最后一个再改变this.data.中的Community_Merchantsimages
    var Menu_images=[]
    Menuimages.forEach(item => {
      console.log(item)
      wx.cloud.uploadFile({
        cloudPath: "Merchants_Menu_images/"+item.substring(item.length-20), // 上传至云端的路径
        filePath: item, // 小程序临时文件路径
        success: res => {
          // 返回文件 ID
          console.log(res.fileID)
          Menu_images.push(res.fileID)
          console.log('这是路径',Menu_images)
          //获取所有图片在云端的位置后上传到数据库
          if(Menu_images.length===Menuimages.length){
            //将局部变量赋给this.data
            this.setData({
              Menu_images:Menu_images
            })
            console.log('这是第二路径',this.data.Menu_images)
            
            //隐藏上传提示
            wx.hideLoading()
            this.uploadMenuData()
          }
        },
        fail: console.error
      })
    });
  },

   //上传数据
   uploadMerchantsData:function () {
    // 送达截止时间戳
    var date = new Date()
    var time = util.formatTime2(new Date().getTime() / 1000, 'Y年M月D日 h:m:s')
    console.log(123)
    const db = wx.cloud.database()
    db.collection("constants").add({
      data: {
        "type":this.data.Merchants_type,
         "describe":this.data.describe,
         "name":this.data.Merchants_name,
         "Community_core":this.data.Community_core,
         "date": date,
         "Time":time,
      },
      success(res) {
        console.log("插入成功")
        
        wx.redirectTo({
          url: "../../Admin/Merchants/Merchants?tab_id=" + 0
        })
      }
    })
  },
     //上传数据
     uploadMerchantsData:function () {
      // 送达截止时间戳
      var date = new Date()
      var time = util.formatTime2(new Date().getTime() / 1000, 'Y年M月D日 h:m:s')
      console.log(123)
      const db = wx.cloud.database()
      db.collection("constants").add({
        data: {
          "type":this.data.Merchants_type,
           "describe":this.data.describe,
           "name":this.data.Merchants_name,
           "Community_core":this.data.Community_core,
           "date": date,
           "Time":time,
        },
        success(res) {
          console.log("插入成功")
          
          wx.redirectTo({
            url: "../../Admin/Merchants/Merchants?tab_id=" + 0
          })
        }
      })
    },
        //判断社团的类型
        typechange: function (e) {
          console.log('picker发送选择改变，携带值为', e.detail.value)
          this.setData({
            type_index: e.detail.value,
            Merchants_type:this.data.choosetype[e.detail.value]
          })
        },
   //判断所属商家
   Canteen_typechange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
     this.setData({
       type_index: e.detail.value,
        Canteen_type:this.data.Canteentype[e.detail.value]
    })
    console.log(this.data.Canteen_type)
 },

          //滑动更新主导航栏下标
          categoriesTab: function (e) {
            this.setData({
              // currentIndex: e.currentTarget.dataset.index
              currentData: e.currentTarget.dataset.index
            })
            console.log(this.data.currentData)
            if(this.data.currentData == 0){
              this.setData({
                eatmode:true
              })
            }else if(this.data.currentData == 1){
              this.setData({
                eatmode:false
              })
            }
          },
//点击删除移除照片
removeMenuImage:function(e) {
  var index = e.target.dataset.index
  //删除指定位置的照片
  var Menuimages=this.data.Menuimages
  Menuimages.splice(index,1)
  this.setData({
    Menuimages:Menuimages
  })
  console.log(index)
  console.log(this.data.Menuimages)
},

  //用户点击放大菜品图片
handleMenuPreview:function(e) {
  var index = e.target.dataset.index
  var Menuimages = this.data.Menuimages
  wx.previewImage({
    current:Menuimages[index],  //当前预览的图片
    urls:Menuimages,  //所有要预览的图片
  })
},
     //隐藏模态窗口
     modalChange(e) {
      this.setData({
        modalName: null
      })
    },
      //将更换完的背景图上传到数据库
      uploadMenuData:function() {
        console.log("上传数据")
        const db = wx.cloud.database()
        const _ = db.command
        db.collection("constants")
        .where({
          name:this.data.Canteen_type
        })
        .update({
          data: {
            "category":_.push({
              category_name:this.data.Menu_name,
              image:this.data.Menu_images,
              category_price:this.data.Menu_price}),
          },
          success: function (res) {
            //成功上传后提示信息
            console.log("上传成功")
            wx.showLoading({
              title: '上传菜品成功',
              icon: 'success',
              duration: 1000,
            })
            wx.redirectTo({
              url: "../../Admin/Merchants/Merchants?tab_id=" + 0
            })
          }
        })
      },
})