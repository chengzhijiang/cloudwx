var util = require('../../../utils/util.js')
Page({
data:{
    animalimages:[],
    inputLength: 0,
    images:[],
    switch: false,
    //选择动物类型
    types: ["喵星人", "汪星人","咕咕咕"],
    type_index:0,
    animals_type:"",
      //可选择联系方式
      contact_wechat: true,
      contact_phone: true,
      //发布的联系方式
      contact_way: "all",
      //LOGO存放在手机中的位置
      LOGOimages:[],
    // 辨别用户第几次点击发布
      display:true,
      // 储存动物名称
      animals_name:"",
      // 动物性别
      animals_sex:"",
      // 发现动物的时间
      animals_findtime:"",
      // 动物位置
      animals_point:"",
      // 动物性格
      animals_Character:"",
      //动物资料
      animals_detail:"",
      //动物大头照在云上的位置
      animals_LOGOimages:[],
      //检验状态
      mode: "",
},
    //判断动物的类型
    bindPickerChange: function (e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        type_index: e.detail.value,
        animals_type:this.data.types[e.detail.value]
      })
    },

 //选择动物大头照图片
 chooseLOGO: function(e) {
  var that = this;
  if (that.data.LOGOimages.length < 1) {
    wx.chooseImage({
      count: 1, //最多可以选择的图片张数
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        this.setData({
          LOGOimages:this.data.LOGOimages.concat(res.tempFilePaths)
        })
        console.log(this.data.LOGOimages)
      }
    });
  } else {
    wx.showToast({
      title: "图片限传一张！",
      icon: 'none',
      duration: 2000,
      mask: true,
    });
  }
},
 //选择动物详细图片
 chooseImage: function(e) {
  var that = this;
  if (that.data.images.length < 3) {
    wx.chooseImage({
      count: 3, //最多可以选择的图片张数
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        this.setData({
          images:this.data.images.concat(res.tempFilePaths)
        })
        console.log(this.data.images)
      }
    });
  } else {
    wx.showToast({
      title: "图片限传三张！",
      icon: 'none',
      duration: 2000,
      mask: true,
    });
  }
},
//检查提交信息
checkInfo:function() {
  // wx.showModal({
  //   title: '物品图片',
  //   content: '上传闲置图片能够更快卖出(是否确认不上传图片)',
  // })
  if (this.data.LOGOimages.length==0) {
    this.setData({
      warning: "请上传动物的大头照",
    })
  } else if (this.data.animals_name=="") {
    this.setData({
      warning: "请给流浪动物起个名字吧！",
    })
  } else if (this.data.animals_type == "") {
    this.setData({
      warning: "请选择小动物的类型",
    })
  } else if (this.data.animals_findtime == "") {
    this.setData({
      warning: "请选择动物的位置",
    })
  } 
  // else if (this.data.images.length === 0) {
  //   this.setData({
  //     warning: "请输入闲置物品的图片",
  //   })
  // } 
  else if (this.data.animals_Character == "") {
    this.setData({
      warning: "请输入动物的性格",
    })
  } else if (this.data.animals_detail == "") {
    this.setData({
      warning: "请简要的描述动物",
    })
  } else {
    this.setData({
      warning: "发布成功",
      mode: true,
      display:false
    })
  }
  this.setData({
    modalName: "Modal",
  })
},

//隐藏模态窗口
modalChange(e) {
  this.setData({
    modalName: null
  })
},
    // submit: function(){
    //   var date = this.dateFormat(new Date())
    //   let promiseArr = [];
    //   var that = this
    //           // 将图片上传至云存储空间
    //           let promise = new Promise((resolve, reject) => {
    //          wx.cloud.uploadFile({
    //            // 指定要上传的文件的小程序临时文件路径
    //            cloudPath:  'animals/' +date+'.png',
    //            filePath: that.data.images[0],
    //            // 成功回调
    //            success: res => {
    //             resolve(res);
    //              that.data.animalimages.push(res.fileID)
    //              console.log(that.data.animalimages)
    //            },
    //            fail: function (error) {
    //             reject(error);
    //            },
    //            complete: function (res) {
    //           },
    //          })
    //         });
    //         promiseArr.push(promise)
    //         that.setData({
    //           spinShow: true
    //         })
            
    //         Promise.all(promiseArr).then((result) => {
    //           console.log(that.data.images)
    //         const db = wx.cloud.database();
    //         db.collection('animals').add({
    //           data: {
    //             "LOGOimages":this.data.LOGOimages,
    //             "animals_name":this.data.animals_name,
    //             "animals_type":this.data.animals_type,
    //             "animals_sex":this.data.sex,
    //             "animals_findtime":this.data.findtime,
    //             "animals_point":this.data.animals_point,
    //             "animals_Character":this.data.animals_Character,
    //             "animals_detail":this.data.animals_detail,
    //             "iamges":that.data.animalimages,
    //             "date": date,
    //             "contact":this.data.contact_way,
    //           }}).then(res => {
    //             wx.showToast({
    //               title: '成功',
    //               success: function (){
    //                 wx.redirectTo({
    //                   url:"../../catanddog/catanddog"
    //                 })
    //               }
    //             })        
    //           })
      
    //       })
    //     },
    //     dateFormat: function (date) { //author: meizz   

    //       var year = date.getFullYear()
    //       var month = date.getMonth() + 1
    //       var day = date.getDate()
    //       var hour = date.getHours()
    //       var minutes = date.getMinutes()
    //       var seconds = date.getSeconds()
    //       var realMonth = month > 9 ? month : "0" + month
    //       return year + "-" + realMonth + "-" + day + " " + hour + ":" + minutes + ":" + seconds
      
    //     },
          //选择微信联系方式
  switch1Change: function (e) {
    console.log('wechat', e.detail.value)
    this.setData({
       contact_wechat: e.detail.value,
    })
    this.contactChange()
    console.log('contact_way值为：', this.data.contact_way)
  },

  //选择手机号联系方式
  switch2Change: function (e) {
    console.log('phone', e.detail.value)
    this.setData({
      contact_phone: e.detail.value,
    })
    this.contactChange()
    console.log('contact_way值为：', this.data.contact_way)
  },

  //选择联系方式
  contactChange: function () {
    if (this.data.contact_wechat && this.data.contact_phone) {
      this.setData({
        contact_way: "all"
      })
    } else if (!this.data.contact_wechat && this.data.contact_phone) {
      this.setData({
        contact_way: "phone"
      })
    } else if (this.data.contact_wechat && !this.data.contact_phone) {
      this.setData({
        contact_way: "wechat"
      })
    }else {
      this.setData({
        contact_way: "none"
      })
    }
  },
  //用户点击放大图片
handleImagePreview:function(e) {
  var index = e.target.dataset.index
  var images = this.data.images
  wx.previewImage({
    current: images[index],  //当前预览的图片
    urls: images,  //所有要预览的图片
  })
},
  //用户点击放大LOGO图片
  handleImagePreview:function(e) {
    var index = e.target.dataset.index
    var LOGOimages = this.data.LOGOimages
    wx.previewImage({
      current: LOGOimages[index],  //当前预览的图片
      urls: LOGOimages,  //所有要预览的图片
    })
  },
//点击删除移除照片
removeImage:function(e) {
  var index = e.target.dataset.index
  //删除指定位置的照片
  var images=this.data.images
  images.splice(index,1)
  this.setData({
    images:images
  })
  console.log(index)
  console.log(this.data.images)
},
//点击删除移除LOGO照片
removeLOGO:function(e) {
  var index = e.target.dataset.index
  //删除指定位置的照片
  var LOGOimages=this.data.LOGOimages
  LOGOimages.splice(index,1)
  this.setData({
    LOGOimages:LOGOimages
  })
  console.log(index)
  console.log(this.data.LOGOimages)
},
  //处理用户填写信息并准备上传
  uploadPost:function(e){
    //得到用户填写的信息
    this.setData({
      animals_name:e.detail.value.animals_name,
      animals_sex:e.detail.value.animals_sex,
      animals_findtime:e.detail.value.animals_firsttime,
      animals_point:e.detail.value.animals_point,
      animals_Character:e.detail.value.animals_Character,
      animals_detail:e.detail.value.animals_detail,
      animals_type:this.data.animals_type,
      mode: false,
    })
    this.checkInfo()

    // 先将照片上传再上传数据库
    if (this.data.mode) {
      if (this.data.LOGOimages.length === 0) {
        console.log("没有上传图片")
        this.setData({
          animals_LOGOimages:this.data.animals_LOGOimages.concat("cloud://yf-ab2989.7966-yf-ab2989-1258230310/没有实物图.png")
        })
        this.uploadData()
      } else {
        this.uploadLOGOImages()
      }
    }
  },
    //统计文本域字数
    bindInput(e) {
      var inputLength = e.detail.value.length;
      this.setData({
        inputLength: inputLength,
      })
    },
 //上传动物大头图片信息
 uploadLOGOImages:function(){
  var LOGOimages=this.data.LOGOimages
  //先添加到这一变量,在最后一个再改变this.data.中的animals_LOGOimages
  var animals_LOGOimages=[]
  LOGOimages.forEach(item => {
    console.log(item)
    wx.cloud.uploadFile({
      cloudPath: "animals_LOGOimages/"+item.substring(item.length-20), // 上传至云端的路径
      filePath: item, // 小程序临时文件路径
      success: res => {
        // 返回文件 ID
        console.log(res.fileID)
        animals_LOGOimages.push(res.fileID)
        console.log(animals_LOGOimages)

        //获取所有图片在云端的位置后上传到数据库
        if(animals_LOGOimages.length===LOGOimages.length){
          //将局部变量赋给this.data
          this.setData({
            animals_LOGOimages:animals_LOGOimages
          })
          console.log(this.data.animals_LOGOimages)
          //隐藏上传提示
          wx.hideLoading()
          this.uploadData()
        }
      },
      fail: console.error
    })
  });
},
 //将帖子信息上传到数据库
 uploadData:function(){
  var date=new Date()
  const db = wx.cloud.database()
  db.collection("animals").add({
    data:{
       "animals_LOGOimages":this.data.animals_LOGOimages,
       "animals_name":this.data.animals_name,
       "type":this.data.animals_type,
        "animals_sex":this.data.animals_sex,
        "animals_findtime":this.data.animals_findtime,
        "animals_point":this.data.animals_point,
        "animals_Character":this.data.animals_Character,
        "animals_detail":this.data.animals_detail,
        "date": date,
        "contact":this.data.contact_way,
    },
    success(res){
      //成功上传后提示信息
      console.log("插入成功")

      // 关闭当前页面，跳转到应用内的某个页面
      wx.redirectTo({
        url:"../../catanddog/catanddog?tab_id=" + 0
      })

      wx.showToast({
        title: '成功发布闲置',
        icon: 'success',
        duration: 1000
      })
    }
  })  
},
onLoad:function(){
  //判断是否注册
  util.isRegistered()
},
})