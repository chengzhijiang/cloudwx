var util = require('../../utils/util.js')
const app = getApp()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    swiperdata: [{ src: "cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/catanddog/cat1.jpg" }, 
    { src: "cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/catanddog/cat2.jpg" },
    {src: "cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/catanddog/20210408183021.jpg"}
      ],
    animation1: null,  
    systemheight: 0,
    flag: false,
    cardname: "",
    cardvalue: "",
    cardsrc: "",
    cardtime:"",
    cardcontent:"",
    cardpoint:"",
    cardCharacter:"",
    alldata:[],
    //所要读取的数据库
    database: 'animals',
    //数据库数量
    count: "",
    //数据库数据
    feed: [],
    //下拉更新数据库数据个数
    nextPage: 0,
    //我的页面
    myPage: true,
    //用户openid
    user_openid: "",
    currentData: 0,
     //流浪猫流浪狗导航
     categories: ["全部", "喵星人", "汪星人","咕咕咕"],
     //分类导航栏下标
     currentData: 0,

  },

   //页面加载时读取数据库
   onLoad: function (options) {
        var height = wx.getSystemInfoSync().windowHeight
    this.setData({
      user_openid: app.globalData.userCloudData._openid,
      systemheight: height,
      itemsrc: options.itemsrc
    })
    var that = this
    // 根据点击查找数据库
    this.userLoad();
  },
    //上传数据
  addanimal:function(){
    wx.navigateTo({
      url: '/pages/Post/upanimal/upanimal',
    })
  },

  // 调用util.js中读取数据库函数
 userLoad: function () {
    var that = this;
      console.log('ask:', that.data.database);
      util.serachanimal(that);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // onLoad: function(options) {
  //   this.getData();
  //   var height = wx.getSystemInfoSync().windowHeight
  //   this.setData({
  //     systemheight: height,
  //     itemsrc: options.itemsrc
  //   })
  // },

 
  // getData: function () {
  //   var that = this;
  //   const db = wx.cloud.database();
  //    db.collection('animals')
  //     .orderBy('date', 'desc')
  //     .get({
  //       //成功读取写入数据
  //       success: res => {
  //         that.setData({
  //           feed: this.data.feed.concat(res.data),

  //         })
  //         console.log('[数据库] [查询记录] 成功: ', that.data.feed)
  //       },
  //       fail: err => {
  //         wx.showToast({
  //           icon: 'none',
  //           title: '查询记录失败'
  //         })
  //         console.error('[数据库] [查询记录] 失败：', err)
  //       }
  //     });
  //   },
  //跳转到点击页面
  animalhome: function (e) {
    var post_data = this.data.currentUrl;
    wx.navigateTo({
      // url: '../posttest/posttest?post_data=' + post_data
      url: '../Index/contact_animals/contact_animals?post_data=' + post_data
    })
  },
  //点击显示遮罩层
  click:function(e){
    console.log(e)
    var index = e.currentTarget.id;
    var sendsrc = this.data.feed[index].animals_LOGOimages;
    var list = this.data.feed;
    var showname = list[index].animals_name;
    var showvalue = list[index].animals_sex;
    var showimgsrc = list[index].animals_LOGOimages;
    var showtime = list[index].animals_findtime;
    var showcontent = list[index].animals_detail;
    var showpoint = list[index].animals_point;
    var showCharacter = list[index].animals_Character;
    var post_data = JSON.stringify(this.data.feed[index])
    this.setData({
      cardname: showname,
      cardvalue: showvalue,
      cardsrc: showimgsrc,
      cardtime:showtime,
      cardcontent:showcontent,
      cardpoint:showpoint,
      cardCharacter:showCharacter
    })
    this.data.currentUrl=post_data;
    var animation = wx.createAnimation({
      duration: 1500,
      delay: 0
    })
    this.animation = animation
    animation.opacity(0).translateY(400).opacity(1).step()
    this.setData({
      animation1: animation.export(),
      flag: true
    })
    var that = this
    setTimeout(function() {
      animation.translateY(0).step()
      that.setData({
        animation1: animation.export()
      })
    }, 150)
  },
  cancellevel: function() {
    var animation = wx.createAnimation({
      duration: 1000,
      timingFunction: "ease",
      delay: 0
    })
    this.animation = animation
    animation.translateY(400).opacity(0).step()
    this.setData({
      animation1: animation.export(),
    })
    var that = this
    setTimeout(function() {
      animation.translateY(0).step()
      that.setData({
        animation1: animation.export(),
        flag: false
      })
    }, 400)
  },
  onTwoCode(){
    wx.cloud.callFunction({
      name:'getTwoCode',
      data:{
        path:'pages/catanddog/catanddog'
      }
    }).then((res)=>{
      console.log('成功',res)
    }
    )
  },
    //滑动更新主导航栏下标
    categoriesTab: function (e) {
      this.setData({
        // currentIndex: e.currentTarget.dataset.index
        currentData: e.currentTarget.dataset.index
      })
      console.log(this.data.currentData)
    },
    //更新副导航栏下标
    categoriesChange: function (e) {
      let current = e.detail.current;
      let source = e.detail.source
      //console.log(source);
      // 这里的source是判断是否是手指触摸 触发的事件
      if (source === 'touch') {
        this.setData({
          currentData: current
        })
        console.log(this.data.currentData)
      }
    },

})