var app = getApp()
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //获取的二手物品数据
    feed: [],
    //下拉继续读取数据
    nextPage: 0,
    //用户id openid
    openid: "",
    //搜索关键词
    keyword: "",
    //闲置数据库
    database: "users",
    //数据库数据
    feed: [],
    //下拉更新数据库数据个数
    nextPage: 0,
    //我的页面
    searchPage: true,
    Menu_price:""

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const db = wx.cloud.database()

    console.log('onLoad')

    //调用获取用户信息数据
    this.allLoad();

    console.log(this.data.feed)
  },



  // 拖到最下面更新数据
  lower: function (e) {
    wx.showNavigationBarLoading();
    var that = this;
    // setTimeout(function(){wx.hideNavigationBarLoading();that.allLoad();}, 1000);
    that.allLoad();
    console.log("lower")
  },

  // 在云数据库上查找数据(查找10条)
  allLoad: function () {
    var that = this;
    // util.allLoad('users', that, '.');
    //查询所有用户
    const db = wx.cloud.database()
    db.collection('users')
    .where({
      "title": db.RegExp({
        regexp: that.data.keyword,
        options: 'i',
      })
    })
      .orderBy('date', 'desc')
      .skip(that.data.nextPage)
      .limit(10) // 限制返回数量为 10 条
      .get({
        //成功读取写入数据
        success: res => {
          that.setData({
            feed: this.data.feed.concat(res.data),
            nextPage: this.data.nextPage + 10
          })
          console.log('[数据库] [查询记录] 成功: ', that.data.feed)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      });
    console.log(this.data.feed)
  },


  updateUser:function(e){
    var that = this
    const idx = e.target.dataset.idx
    var user_openid = this.data.feed[idx]._openid
    var Menu_price = this.data.Menu_price
    var user_id = this.data.feed[idx]._id
    console.log(Menu_price)
    console.log(this.data.Menu_price)
    wx.showModal({
      title:'确认充值',
      content: "确认为该用户充值吗",
      success (res) {
        if (res.confirm) {
        // 调用云函数修改用户信息
        wx.cloud.callFunction({
          name: 'investmoney',
          data: {
            user_id: user_id,
            Totalrevenue: Number(Menu_price)
          }, success: function (res) {
            console.log("修改成功" + res)
            wx.redirectTo({
              url: "../investmoney/investmoney?tab_id=" + 0
            })
          }, fail: function (res) {
            console.log(res)
          }
        })
        // 调用模板消息发送消息
        that.sendTemplate("认证成功", user_openid)
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
  })
  },
  // 发送模板消息
  sendTemplate: function (approve, user_openid) {
    console.log(user_openid)
    wx.cloud.init()
    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendRegisteredMessage',
        approve: approve,
        user_openid: user_openid
      },
      success: res => {
        console.warn('[云函数] [openapi] templateMessage.send 调用成功：', res)
        wx.showModal({
          title: '发送成功',
          content: '成功发送信息',
          showCancel: false,
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '调用失败',
        })
        console.error('[云函数] [openapi] templateMessage.send 调用失败：', err)
      }
    })
  },


  //用户点击放大图片
  handleImagePreview:function(e) {
    var index = e.target.dataset.index
    console.log(e)
    var images = this.data.feed[index].approve_img
    wx.previewImage({
      current: images[index],  //当前预览的图片
      urls: images,  //所有要预览的图片
    })
  },

  //刷新注册用户
  refresh:function() {
    this.setData({
      //获取的二手物品数据
      feed: [],
      //下拉继续读取数据
      nextPage: 0,
    })
    this.allLoad();
  },

  // 记录搜索关键词
  inputKeyword: function (e) {
    var data = e.detail.value;
    this.setData({
      keyword: data,
    })
  },
  inputMenu_price:function(e){
    var data = e.detail.value
    this.setData({
      Menu_price:data
    })
    console.log(this.data.Menu_price)
  },
    //通过关键词搜索用户
    searchByKeyword: function() {
      this.setData({
        feed: [],
        nextPage: 0,
      })
      if (this.data.keyword == '') {
        this.setData({
          keyword: '.',
        })
      }
      var that = this
      util.searcmanager(that)
      console.log(this.data.feed)
    },

        //更改user的manager为true
        changemanager:function() {
          console.log("上传数据")
        
        },
})