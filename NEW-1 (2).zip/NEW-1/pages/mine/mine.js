var util = require('../../utils/util.js')
const app = getApp()
Page({
  data:{
    userData:[],
    //头像列表
    swiperList: [],
    openid:"",
  },
    // 登录操作(从云上获取用户信息)
    login: function(){
      //获取用户的openid并设置为全局变量
      wx.cloud.callFunction({
        name: 'login',
        complete: res => {
          console.log('callFunction test result: ', res)
          this.setData({
            openid: res.result.openid
          })
          util.getUserInCloud(this.data.openid);
        }
      })
    },

  onShow: function (options) {
    // this.uploadUser()
    // 判断是否显示管理员页面
    this.setData({
      swiperList: app.globalData.swiperList,
      userData: app.globalData.userCloudData
    })
    //获取用户的openid并设置为全局变量
    this.login();

  },
  onLoad: function () {
this.setData({
  navH: app.globalData.navHeight
})

  },
  //页面跳转
  myuserinfo:function(){
    wx.navigateTo({
      url: '/pages/renzheng/Mine/userInfo/userInfo',
    })
  },
  myOrder:function(){
    wx.navigateTo({
      url: '/pages/Index/myorder/myorder',
    })
  },
tutrenzheng:function(){
  wx.navigateTo({
    url: '/pages/renzheng/Mine/registered/registered',
  })
},
myGoods:function(){
  wx.navigateTo({
    url: '/pages/News/myGoods/myGoods',
  })
},
myExpress:function(){
  wx.navigateTo({
    url: '/pages/News/myExpress/myExpress',
  })
},
myDiscover:function(){
wx.navigateTo({
  url: '/pages/News/myDiscover/myDiscover',
})
},
myanimals:function(){
  wx.navigateTo({
    url: '/pages/News/myanimals/myanimals',
  })
},
myluntan:function(){
  wx.navigateTo({
    url: '/pages/News/myluntan/myluntan',
  })
},
// 跳转我的社团页面
myCommunity:function(){
  wx.navigateTo({
    url: '/pages/News/myCommunity/myCommunity',
  })
},
// 跳转至社长页面
shezhang:function(){
wx.navigateTo({
  url: '/pages/Admin/shezhang/shezhang',
})
},
  // 跳转管理员页面
  administrator:function(){
    wx.navigateTo({
      url:"../Admin/admin_main/admin_main"
    })
  },
  takeout:function(){
    wx.navigateTo({
      url: '../Index/takeout/takeout',
    })
  },
  mytakeout:function(){
    wx.navigateTo({
      url: '../Index/mytakeout/mytakeout',
    })
  },
  Canteenattendant:function(){
    wx.navigateTo({
      url: '../Canteenattendant/Canteenattendant',
    })
  },
  investmoney:function(){
    wx.navigateTo({
      url: '../investmoney/investmoney',
    })
  },
      //检查用户是否已经注册(决定点击跳转到的页面)
  checkUser:function(){
    console.log(this.data.userData)
    if (app.globalData.userCloudData.approve==="0") {
      wx.navigateTo({
        url:"../renzheng/Mine/registered/registered"
      })
    }else {
      wx.navigateTo({
        url: "../renzheng/Mine/userInfo/userInfo"
      })
    }
  },
    //用户联系方式复制
    showConnect:function (e) {
      console.log(123)
      wx.showModal({
        title:'余额充值联系微信',
        content: "18309517094",
        confirmText:"复制",
        success (res) {
          if (res.confirm) {
            wx.setClipboardData({
              data:"18309517094",
              success: function (res) {
                wx.showToast({
                  title: '复制成功',
                });
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
    })
    
    },
})