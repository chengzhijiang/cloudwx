var util = require('../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
        //帖子信息
        post_data:{},
        bookbalance:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var post_data=JSON.parse(options.post_data)
    this.setData({
      post_data:post_data,
      userData: app.globalData.userCloudData,
  })
  console.log(post_data)
  console.log(this.data.userData)
  },

  radioClick:function(e){
    console.log(e);
    let payment =e.detail.value;
    if( payment == "账户余额"){
      if(this.data.userData.Totalrevenue > this.data.post_data.Allprice){
        this.setData({
          bookbalance:Number(this.data.userData.Totalrevenue) - Number(this.data.post_data.Allprice)
        })
        console.log(this.data.bookbalance)
      }else{
        wx.showToast({
          title: "账户余额不足哦！",
          icon: 'none',
          duration: 1500,
          mask: true
        });
      }
    }else if(payment == "微信支付"){
      wx.showToast({
        title: "程序猿正在努力中ing",
        icon: 'none',
        duration: 1500,
        mask: true
      });
    }
  },
  // 生成订单以及更新用户余额
  uploadPost:function(e){
    var that = this
    this.setData({
      bookbalance:this.data.bookbalance
    })
    if(this.data.userData.Totalrevenue > this.data.post_data.Allprice){
    console.log(this.data.post_data)
    wx.showModal({
      title:'确认支付',
      content: "是否要支付￥"+this.data.post_data.Allprice,
      success (res) {
        if (res.confirm) {
          that.uploadData()
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
  })
}else{
  wx.showToast({
    title: "账户余额不足哦！",
    icon: 'none',
    duration: 1500,
    mask: true
  });
}
},
// 在用户信息表上加入社团信息
uploadData:function() {
  var that = this
  console.log("上传数据")
  const db = wx.cloud.database()
  db.collection("users").doc(app.globalData.userCloudData._id).update({
    data: {
      "Totalrevenue":this.data.bookbalance,
    },
    success: function (res) {
      that.uploadorder()
      //成功上传后提示信息
      console.log("购买成功")
      wx.showLoading({
        title: '购买成功',
        icon: 'success',
        duration: 1000,
      })
      
    }
  })
},
  //上传数据
  uploadorder:function() {
    console.log("上传数据")
    var date = util.formatTime2(new Date().getTime() / 1000, 'Y年M月D日 h:m:s')
    const db = wx.cloud.database()
    db.collection("order").add({
      data: {
        "catererphone":this.data.post_data.catererphone,
        "category_name":this.data.post_data.category_name,
        "category_price":this.data.post_data.category_price,
        "express_destination":this.data.post_data.express_destination,
        "express_time":this.data.post_data.express_time,
        "Takeawaynotes":this.data.post_data.Takeawaynotes,
        "type":this.data.post_data.type,
        "time":date,
        "date":new Date().getTime(),
        "Delivery":false,
        "Merchant_confirmed":false,
        "Receiving":false,
      },
      success: function(res) {
        //成功上传后提示信息
        console.log("上传成功")
        wx.redirectTo({
          url: '../Index/myorder/myorder',
        })
      }
    })
  },
})