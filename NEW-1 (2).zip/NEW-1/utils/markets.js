
/**
 * 假设这是服务器获取的数据
 */

const constants = [
  {
    "id": "id1",
    "name": "🍇新鲜水果",
    "describe": "今日优质新鲜蔬果推荐",
    "category": [
      {
        "category_id": 1,
        "category_name": "西瓜果切一盒",
        "num":0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/Watermelon.png",
        "price":"10"
      },
      {
        "category_id": 2,
        "category_name": "新鲜芒果",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/Mangoes.jpg",
        "price":"10"
      },
      {
        "category_id": 3,
        "category_name": "葡萄一盒",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/Grapes.jpg",
        "price":"10"
      },
      {
        "category_id": 4,
        "category_name": "哈密瓜果切一盒",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/Cantaloupe.jpg",
        "price":"10"
      },      {
        "category_id": 5,
        "category_name": "新鲜草莓一盒",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/Strawberries.jpg",
        "price":"10"
      }
    ],
  },
  {
    "id": "id2",
    "name": "🔧数码维修",
    "describe": "维修师傅将尽快联系您",
    "category": [
      {
        "category_id": 4,
        "category_name": "电脑维修预付定金",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/computer.png",
        "price":"15"
      },
      {
        "category_id": 5,
        "category_name": "手机维修预付定金",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/mobliephone.png",
        "price":"15"
      },
      {
        "category_id": 6,
        "category_name": "苹果电脑系统重装",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/iPhone.png",
        "price":"35"
      },
      {
        "category_id": 7,
        "category_name": "微软电脑系统重装",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/windows.png",
        "price":"30"
      },
      {
        "category_id": 8,
        "category_name": "电脑清灰",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/clean.png",
        "price":"30"
      }, {
        "category_id": 9,
        "category_name": "配钥匙",
        "num": 0,
        "image":"cloud://chenzhijiang-4gjcxfns965a56d9.6368-chenzhijiang-4gjcxfns965a56d9-1303874313/marketimages/key.png",
        "price":"10"
      },
    ]
  },
 
]

module.exports =  constants

